# Huong dan cuc bo cho Codex

- Sau khi hoan tat cac thay doi duoc yeu cau va da kiem tra hop ly, tu dong commit va push len git de ban chinh duoc cap nhat, tru khi nguoi dung yeu cau khong push hoac repo dang co thay doi khong lien quan can tranh cham vao.
- Khong revert, stage, commit, hay push cac thay doi khong lien quan den nhiem vu hien tai neu chua duoc nguoi dung yeu cau ro.
- File nay la ghi chu cuc bo cua du an, khong duoc dua len git.
