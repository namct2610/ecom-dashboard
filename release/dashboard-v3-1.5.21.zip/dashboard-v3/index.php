<?php
require_once __DIR__ . '/includes/bootstrap.php';

start_session();

// Generate CSRF token
$csrf = generate_csrf();

$appVersion = file_exists(__DIR__ . '/version.txt')
    ? trim((string) file_get_contents(__DIR__ . '/version.txt'))
    : '0.0.0';
$appUpdatedAt = '';
$manifestPath = __DIR__ . '/manifest.json';
if (file_exists($manifestPath)) {
    $manifestPayload = json_decode((string) file_get_contents($manifestPath), true);
    if (is_array($manifestPayload) && !empty($manifestPayload['released_at'])) {
        $releaseAt = date_create((string) $manifestPayload['released_at']);
        $appUpdatedAt = $releaseAt ? $releaseAt->format('d/m/Y H:i') : (string) $manifestPayload['released_at'];
    }
}
if ($appUpdatedAt === '' && file_exists($manifestPath)) {
    $appUpdatedAt = date('d/m/Y H:i', filemtime($manifestPath) ?: time());
}
$appVersionLabel = 'v' . $appVersion;
$appVersionMeta = $appUpdatedAt !== '' ? $appVersionLabel . ' · ' . $appUpdatedAt : $appVersionLabel;

// Detect current user initials for avatar
$user = $_SESSION['username'] ?? 'A';
$initials = strtoupper(substr($user, 0, 2));
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard v3</title>
  <meta name="csrf-token" content="<?= htmlspecialchars($csrf) ?>">

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="assets/css/variables.css">
  <link rel="stylesheet" href="assets/css/base.css">
  <link rel="stylesheet" href="assets/css/layout.css">
  <link rel="stylesheet" href="assets/css/components.css">
  <link rel="stylesheet" href="assets/css/charts.css">
  <link rel="stylesheet" href="assets/css/admin.css">
  <link rel="stylesheet" href="assets/css/upload.css">

  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <!-- i18n (load before app.js so t() is available) -->
  <script src="assets/js/i18n.js"></script>
</head>
<body>

<!-- ── Auth Overlay ──────────────────────────────────────────────────────── -->
<div id="auth-screen" class="hidden">
  <div class="login-box">
    <div class="login-logo">
      <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="3" y="12" width="3.5" height="7" rx="1.2" fill="currentColor" opacity="0.28"/>
        <rect x="9.25" y="8" width="3.5" height="11" rx="1.2" fill="currentColor" opacity="0.55"/>
        <rect x="15.5" y="4.5" width="3.5" height="14.5" rx="1.2" fill="currentColor"/>
        <path d="M4 8.25C5.5 8.25 6.36 8.8 7.72 10.05C8.91 11.15 9.68 11.63 10.61 11.63C11.83 11.63 12.68 10.82 13.91 9.45C15.29 7.91 16.49 7 18.62 7" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
        <circle cx="4" cy="8.25" r="1.25" fill="currentColor" opacity="0.85"/>
        <circle cx="18.62" cy="7" r="1.5" fill="currentColor"/>
      </svg>
    </div>
    <div class="login-title">Dashboard v3</div>
    <div class="login-sub" data-i18n="login.sub">Đăng nhập để tiếp tục</div>
    <form id="loginForm" autocomplete="off">
      <div class="login-field">
        <label class="login-label" data-i18n="login.user" for="loginUsername">Tên đăng nhập</label>
        <input id="loginUsername" class="login-input" type="text" placeholder="admin" autocomplete="username" required>
      </div>
      <div class="login-field">
        <label class="login-label" data-i18n="login.pass" for="loginPassword">Mật khẩu</label>
        <input id="loginPassword" class="login-input" type="password" placeholder="••••••••" autocomplete="current-password" required>
      </div>
      <button id="loginBtn" data-i18n="login.btn" type="submit" class="login-btn">Đăng nhập</button>
      <div id="loginError" class="login-error"></div>
    </form>
  </div>
</div>

<!-- ── Toast Container ───────────────────────────────────────────────────── -->
<div id="toast-container"></div>

<!-- ── App Shell ─────────────────────────────────────────────────────────── -->
<div id="app">

  <!-- Sidebar -->
  <nav id="sidebar">
    <div class="sidebar-brand">
      <div class="sidebar-brand-icon">
        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <rect x="3" y="12" width="3.5" height="7" rx="1.2" fill="currentColor" opacity="0.28"/>
          <rect x="9.25" y="8" width="3.5" height="11" rx="1.2" fill="currentColor" opacity="0.55"/>
          <rect x="15.5" y="4.5" width="3.5" height="14.5" rx="1.2" fill="currentColor"/>
          <path d="M4 8.25C5.5 8.25 6.36 8.8 7.72 10.05C8.91 11.15 9.68 11.63 10.61 11.63C11.83 11.63 12.68 10.82 13.91 9.45C15.29 7.91 16.49 7 18.62 7" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="4" cy="8.25" r="1.25" fill="currentColor" opacity="0.85"/>
          <circle cx="18.62" cy="7" r="1.5" fill="currentColor"/>
        </svg>
      </div>
      <div class="sidebar-brand-text">
        <div class="sidebar-brand-name">Dashboard v3</div>
        <div class="sidebar-brand-meta"><?= htmlspecialchars($appVersionMeta, ENT_QUOTES, 'UTF-8') ?></div>
      </div>
    </div>

    <div class="sidebar-nav">
      <!-- Group 1: Tổng quan -->
      <div class="nav-group" data-group="overview">
        <div class="nav-item nav-parent active" data-page="overview" data-label="Tổng quan">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
          <span class="nav-label" data-i18n="nav.overview">Tổng quan</span>
          <span class="nav-chevron" aria-hidden="true">›</span>
        </div>
        <div class="nav-children">
          <div class="nav-item nav-child" data-page="plan" data-label="Kế hoạch">
            <span class="nav-label" data-i18n="nav.plan">Kế hoạch</span>
          </div>
          <div class="nav-item nav-child" data-page="comparison" data-label="So sánh">
            <span class="nav-label" data-i18n="nav.comparison">So sánh</span>
          </div>
        </div>
      </div>

      <!-- Group 2: Đơn hàng -->
      <div class="nav-group" data-group="orders">
        <div class="nav-item nav-parent" data-page="orders" data-label="Đơn hàng">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
          <span class="nav-label" data-i18n="nav.orders">Đơn hàng</span>
          <span class="nav-chevron" aria-hidden="true">›</span>
        </div>
        <div class="nav-children">
          <div class="nav-item nav-child" data-page="heatmaps" data-label="Phân tích">
            <span class="nav-label" data-i18n="nav.analytics">Phân tích</span>
          </div>
        </div>
      </div>

      <!-- Group 3: Sản phẩm -->
      <div class="nav-group" data-group="products">
        <div class="nav-item nav-parent" data-page="products" data-label="Sản phẩm">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
          <span class="nav-label" data-i18n="nav.products">Sản phẩm</span>
          <span class="nav-chevron" aria-hidden="true">›</span>
        </div>
        <div class="nav-children">
          <div class="nav-item nav-child" data-page="product-list" data-label="Danh sách sản phẩm">
            <span class="nav-label" data-i18n="nav.product_list">Danh sách sản phẩm</span>
          </div>
          <div class="nav-item nav-child" data-page="data-link" data-label="Liên kết dữ liệu sàn">
            <span class="nav-label" data-i18n="nav.data_link">Liên kết dữ liệu sàn</span>
          </div>
        </div>
      </div>

      <!-- Group 4: Khách hàng -->
      <div class="nav-group" data-group="customers">
        <div class="nav-item nav-parent" data-page="customers" data-label="Khách hàng">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
          <span class="nav-label" data-i18n="nav.customers">Khách hàng</span>
          <span class="nav-chevron" aria-hidden="true">›</span>
        </div>
        <div class="nav-children">
          <div class="nav-item nav-child" data-page="traffic" data-label="Lượng truy cập">
            <span class="nav-label" data-i18n="nav.traffic">Lượng truy cập</span>
          </div>
        </div>
      </div>

      <!-- Group 5: Cài đặt -->
      <div class="nav-group" data-group="settings">
        <div class="nav-item nav-parent" data-page="settings-account" data-label="Cài đặt">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
          <span class="nav-label" data-i18n="nav.settings">Cài đặt</span>
          <span class="nav-chevron" aria-hidden="true">›</span>
        </div>
        <div class="nav-children">
          <div class="nav-item nav-child" data-page="settings-account" data-label="Cài đặt tài khoản">
            <span class="nav-label" data-i18n="nav.settings_account">Cài đặt tài khoản</span>
          </div>
          <div class="nav-item nav-child" data-page="settings-lang" data-label="Cài đặt ngôn ngữ">
            <span class="nav-label" data-i18n="nav.settings_lang">Cài đặt ngôn ngữ</span>
          </div>
        </div>
      </div>

      <!-- Group 6: Hệ thống -->
      <div class="nav-group" data-group="system">
        <div class="nav-item nav-parent" data-page="system" data-label="Hệ thống">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="16" height="6" rx="2"/><rect x="4" y="14" width="16" height="6" rx="2"/><line x1="8" y1="7" x2="8.01" y2="7"/><line x1="8" y1="17" x2="8.01" y2="17"/></svg>
          <span class="nav-label" data-i18n="nav.system">Hệ thống</span>
          <span class="nav-chevron" aria-hidden="true">›</span>
        </div>
        <div class="nav-children">
          <div class="nav-item nav-child" data-page="reconcile" data-label="Đối soát GBS">
            <span class="nav-label" data-i18n="nav.reconcile">Đối soát GBS</span>
          </div>
          <div class="nav-item nav-child" data-page="upload" data-label="Upload">
            <span class="nav-label" data-i18n="nav.upload">Upload</span>
          </div>
          <div class="nav-item nav-child" data-page="logs" data-label="Nhật ký">
            <span class="nav-label" data-i18n="nav.logs">Nhật ký</span>
          </div>
        </div>
      </div>
    </div>

    <div class="sidebar-footer">
      <a href="beta/" class="btn-try-beta" title="UI mới v2.0.0 — dùng chung database" data-i18n-title="beta.try_title">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12l5 5L20 7"/></svg>
        <span class="nav-label" data-i18n="beta.try">Thử bản beta v2.0.0</span>
      </a>
      <button id="btnCollapseSidebar" class="btn-collapse-sidebar">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
        <span class="nav-label" data-i18n="nav.collapse">Thu gọn</span>
      </button>
      <button id="btnLogout" class="btn-logout">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/></svg>
        <span class="btn-logout-label" data-i18n="nav.logout">Đăng xuất</span>
      </button>
    </div>
  </nav>

  <!-- Main -->
  <div id="main">

    <!-- Sidebar overlay (mobile) -->
    <div id="sidebarOverlay"></div>

    <!-- Header -->
    <div id="header">
      <button id="btnMenuToggle" aria-label="Menu">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
      </button>
      <span class="header-title">Dashboard v3</span>

      <!-- Platform filter -->
      <div class="platform-filter">
        <button class="platform-btn active" data-platform="all" data-i18n="filter.all">Tất cả</button>
        <button class="platform-btn" data-platform="shopee">Shopee</button>
        <button class="platform-btn" data-platform="lazada">Lazada</button>
        <button class="platform-btn" data-platform="tiktokshop">TikTok</button>
      </div>

      <!-- View mode toggle: COMBO ↔ SKU -->
      <div class="view-mode-toggle" title="Hiển thị sản phẩm dạng nguyên gốc từ sàn hoặc tách thành SKU đơn lẻ" data-i18n-title="view_mode.title">
        <button class="view-mode-btn active" data-view-mode="combo">COMBO</button>
        <button class="view-mode-btn" data-view-mode="sku">SKU</button>
      </div>

      <div class="header-spacer"></div>

      <!-- Period picker -->
      <div class="period-picker" id="periodPicker">
        <div class="pp-modes">
          <button class="pp-mode active" data-mode="month" data-i18n="period.month">Tháng</button>
          <button class="pp-mode" data-mode="year" data-i18n="period.year">Năm</button>
        </div>
        <div class="pp-nav">
          <button class="pp-arrow" id="periodPrev">&#8249;</button>
          <button class="pp-label" id="periodLabelBtn">
            <span id="periodLabel">--</span>
            <span class="pp-caret">&#9660;</span>
          </button>
          <button class="pp-arrow" id="periodNext">&#8250;</button>
        </div>
        <div class="pp-panel" id="periodPanel">
          <div class="pp-presets">
            <button class="pp-preset pp-preset-range" data-preset="today" data-i18n="preset.today">Hôm nay</button>
            <button class="pp-preset pp-preset-range" data-preset="yesterday" data-i18n="preset.yesterday">Hôm qua</button>
            <button class="pp-preset pp-preset-range" data-preset="7days" data-i18n="preset.7days">7 ngày</button>
            <button class="pp-preset pp-preset-range" data-preset="30days" data-i18n="preset.30days">30 ngày</button>
          </div>
          <div class="pp-presets pp-presets-period">
            <button class="pp-preset" data-preset="this-month" data-i18n="preset.this_month">Tháng này</button>
            <button class="pp-preset" data-preset="last-month" data-i18n="preset.last_month">Tháng trước</button>
            <button class="pp-preset" data-preset="this-year" data-i18n="preset.this_year">Năm nay</button>
          </div>
          <div class="pp-grid-head">
            <button class="pp-gyear-arrow" id="periodGridPrev">&#8249;</button>
            <span id="periodGridYear">2026</span>
            <button class="pp-gyear-arrow" id="periodGridNext">&#8250;</button>
          </div>
          <div class="pp-grid" id="periodGrid"></div>
        </div>
      </div>

      <div class="user-menu" id="userMenu">
        <button class="user-menu-btn" id="btnUserMenu" type="button" aria-haspopup="true" aria-expanded="false">
          <span id="adminNavBadge" class="user-menu-badge" style="display:none"></span>
          <div class="user-menu-meta">
            <span class="user-menu-name" id="headerUserName"><?= htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username'] ?? '') ?></span>
            <span class="user-menu-role" id="headerUserRole"><?= htmlspecialchars($_SESSION['role'] ?? 'staff') ?></span>
          </div>
          <div class="header-avatar" id="headerAvatar"><?= htmlspecialchars($initials) ?></div>
          <svg class="user-menu-caret" viewBox="0 0 10 6" width="8" height="8" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M1 1l4 4 4-4"/></svg>
        </button>

        <div class="user-menu-dropdown" id="userMenuDropdown">
          <div class="user-menu-card">
            <div class="user-menu-card-avatar" id="userMenuAvatar"><?= htmlspecialchars($initials) ?></div>
            <div class="user-menu-card-info">
              <div class="user-menu-card-name" id="userMenuName"><?= htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username'] ?? '') ?></div>
              <div class="user-menu-card-username" id="userMenuUsername">@<?= htmlspecialchars($_SESSION['username'] ?? 'guest') ?></div>
              <div class="user-menu-card-role" id="userMenuRole"><?= htmlspecialchars($_SESSION['role'] ?? 'staff') ?></div>
            </div>
          </div>

          <div class="user-menu-divider"></div>

          <button class="user-menu-item" id="btnUserMenuProfile" type="button">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21a8 8 0 00-16 0"/><circle cx="12" cy="8" r="4"/></svg>
            <span data-i18n="user.menu.profile">Hồ sơ tài khoản</span>
          </button>

          <button class="user-menu-item" id="btnUserMenuPassword" type="button">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="10" rx="2"/><path d="M7 11V8a5 5 0 0110 0v3"/><circle cx="12" cy="16" r="1"/></svg>
            <span data-i18n="user.menu.password">Đổi mật khẩu</span>
          </button>

          <div class="user-menu-divider"></div>

          <div class="user-menu-lang-head">
            <span data-i18n="user.menu.language">Ngôn ngữ hiển thị</span>
            <span class="user-menu-lang-current" id="userMenuLangCurrent">VI</span>
          </div>
          <div class="user-menu-lang-list" id="userMenuLangList"></div>

          <button class="user-menu-item admin-only hidden-by-role" id="btnUserMenuLangSettings" type="button">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M12 4h9"/><path d="M4 9h16"/><path d="M4 15h16"/><path d="M8 4v16"/></svg>
            <span data-i18n="user.menu.language_settings">Cài đặt ngôn ngữ</span>
          </button>

          <button class="user-menu-item admin-only hidden-by-role" id="btnUserMenuAdmin" type="button">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l7 4v5c0 5-3.1 8.7-7 9.9C8.1 20.7 5 17 5 12V7l7-4z"/><path d="M9.5 12.5l1.8 1.8 3.9-4.2"/></svg>
            <span data-i18n="user.menu.admin">Quản trị hệ thống</span>
          </button>

          <div class="user-menu-divider"></div>

          <button class="user-menu-item" id="btnUserMenuLogout" type="button">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>
            <span data-i18n="nav.logout">Đăng xuất</span>
          </button>
        </div>
      </div>
    </div>

    <!-- Content -->
    <div id="content">

      <!-- ── Overview ──────────────────────────────────────────────────── -->
      <div class="page active" id="page-overview">
        <div class="page-header">
          <h1 data-i18n="page.overview.title">Tổng quan</h1>
          <p data-i18n="page.overview.sub">Doanh thu, đơn hàng và traffic tổng hợp</p>
        </div>

        <!-- KPI Row -->
        <div class="grid-4 mb-4">
          <div class="kpi-card border-blue">
            <div class="kpi-label"><span data-i18n="kpi.revenue">Doanh thu</span>
              <span class="kpi-icon blue">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
              </span>
            </div>
            <div class="kpi-value" id="kpi-revenue">—</div>
            <div class="kpi-sub" data-i18n="kpi.revenue.sub">Đã hoàn thành</div>
          </div>
          <div class="kpi-card border-green">
            <div class="kpi-label"><span data-i18n="kpi.orders">Tổng đơn</span>
              <span class="kpi-icon green">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/></svg>
              </span>
            </div>
            <div class="kpi-value" id="kpi-orders">—</div>
            <div class="kpi-sub" data-i18n="kpi.orders.sub">Tất cả trạng thái</div>
          </div>
          <div class="kpi-card border-purple">
            <div class="kpi-label"><span data-i18n="kpi.completed">Hoàn thành</span>
              <span class="kpi-icon purple">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
              </span>
            </div>
            <div class="kpi-value" id="kpi-completed">—</div>
            <div class="kpi-sub" data-i18n="kpi.completed.sub">Đã giao / hoàn thành</div>
          </div>
          <div class="kpi-card border-orange">
            <div class="kpi-label"><span data-i18n="kpi.views">Lượt xem</span>
              <span class="kpi-icon orange">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              </span>
            </div>
            <div class="kpi-value" id="kpi-views">—</div>
            <div class="kpi-sub"><span data-i18n="kpi.visits">Lượt truy cập</span>: <span id="kpi-visitors">—</span></div>
          </div>
        </div>

        <!-- Revenue trend + platform donut -->
        <div class="grid-3-1">
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.revenue_trend">Doanh thu theo thời gian</h3>
                <p data-i18n="chart.by_platform">Phân theo sàn</p>
              </div>
            </div>
            <div class="chart-wrap" style="height:200px">
              <canvas id="chartRevenueTrend"></canvas>
            </div>
          </div>
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.market_share">Thị phần doanh thu</h3>
              </div>
            </div>
            <div class="donut-wrap" style="height:160px">
              <canvas id="chartPlatformDonut"></canvas>
            </div>
            <div id="platformLegend" style="margin-top:12px"></div>
          </div>
        </div>

        <!-- Recent orders + top products -->
        <div class="grid-2">
          <div class="card">
            <div class="card-title" data-i18n="card.recent_orders">Đơn hàng gần đây</div>
            <div id="recentOrdersMini"></div>
          </div>
          <div class="card">
            <div class="card-title" data-i18n="card.top_products">Top sản phẩm</div>
            <div id="topProductsOverview"></div>
          </div>
        </div>
      </div>

      <!-- ── Orders ────────────────────────────────────────────────────── -->
      <div class="page" id="page-orders">
        <div class="page-header">
          <h1 data-i18n="page.orders.title">Đơn hàng</h1>
          <p data-i18n="page.orders.sub">Chi tiết đơn hàng theo thời gian và trạng thái</p>
        </div>

        <!-- KPIs -->
        <div class="grid-4 mb-4">
          <div class="kpi-card border-blue">
            <div class="kpi-label" data-i18n="kpi.total_orders">Tổng đơn</div>
            <div class="kpi-value" id="ord-total">—</div>
          </div>
          <div class="kpi-card border-green">
            <div class="kpi-label" data-i18n="kpi.completed">Hoàn thành</div>
            <div class="kpi-value" id="ord-completed">—</div>
          </div>
          <div class="kpi-card border-red">
            <div class="kpi-label" data-i18n="kpi.cancelled">Đã huỷ</div>
            <div class="kpi-value" id="ord-cancelled">—</div>
          </div>
          <div class="kpi-card border-orange">
            <div class="kpi-label" data-i18n="kpi.cancel_rate">Tỷ lệ huỷ</div>
            <div class="kpi-value" id="ord-cancel-rate">—</div>
          </div>
        </div>

        <!-- Order trend + donut -->
        <div class="grid-3-1">
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.order_trend">Xu hướng đơn hàng</h3>
                <p data-i18n="chart.completed_vs_cancelled">Hoàn thành vs Huỷ</p>
              </div>
            </div>
            <div class="chart-wrap" style="height:200px">
              <canvas id="chartOrdersTrend"></canvas>
            </div>
          </div>
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.order_status">Trạng thái đơn</h3>
              </div>
            </div>
            <div class="donut-wrap" style="height:160px">
              <canvas id="chartOrdersStatus"></canvas>
            </div>
            <div id="statusLegend" style="margin-top:10px"></div>
          </div>
        </div>

        <!-- Platform orders + hourly -->
        <div class="grid-2">
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.orders_platform">Đơn theo sàn</h3>
              </div>
            </div>
            <div class="chart-wrap" style="height:180px">
              <canvas id="chartPlatformOrders"></canvas>
            </div>
          </div>
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.orders_hour">Đơn theo giờ trong ngày</h3>
              </div>
            </div>
            <div class="chart-wrap" style="height:180px">
              <canvas id="chartHourly"></canvas>
            </div>
          </div>
        </div>

        <!-- Orders table -->
        <div class="card">
          <div class="card-title" data-i18n="card.order_list">Danh sách đơn hàng</div>
          <div class="table-wrapper" style="margin-top:10px">
            <table>
              <thead>
                <tr>
                  <th data-i18n="th.order_id">Mã đơn</th>
                  <th data-i18n="th.product">Sản phẩm</th>
                  <th data-i18n="th.platform">Sàn</th>
                  <th data-i18n="th.date">Ngày đặt</th>
                  <th class="text-right" data-i18n="th.value">Giá trị</th>
                  <th data-i18n="th.status">Trạng thái</th>
                </tr>
              </thead>
              <tbody id="ordersTable"></tbody>
            </table>
          </div>
          <div id="ordersPager"></div>
        </div>
      </div>

      <!-- ── Products ──────────────────────────────────────────────────── -->
      <div class="page" id="page-products">
        <div class="page-header">
          <h1 data-i18n="page.products.title">Sản phẩm</h1>
          <p data-i18n="page.products.sub">Top sản phẩm theo số lượng và doanh thu</p>
        </div>

        <div class="grid-4 mb-4">
          <div class="kpi-card border-purple">
            <div class="kpi-label" data-i18n="kpi.total_skus">Tổng SKU</div>
            <div class="kpi-value" id="total-skus">—</div>
          </div>
          <div class="kpi-card border-blue">
            <div class="kpi-label" data-i18n="kpi.qty_sold">Tổng SL đã bán</div>
            <div class="kpi-value" id="prod-qty-all">—</div>
            <div class="kpi-sub" data-i18n="kpi.qty_sold.sub">Kể cả đơn huỷ</div>
          </div>
          <div class="kpi-card border-green">
            <div class="kpi-label" data-i18n="kpi.qty_delivered">Tổng SL đã giao</div>
            <div class="kpi-value" id="prod-qty-delivered">—</div>
            <div class="kpi-sub" data-i18n="kpi.qty_del.sub">Đơn hoàn thành</div>
          </div>
          <div class="kpi-card border-orange">
            <div class="kpi-label" data-i18n="kpi.avg_qty">SL TB/đơn hàng</div>
            <div class="kpi-value" id="prod-avg-qty">—</div>
            <div class="kpi-sub" data-i18n="kpi.avg_qty.sub">Sản phẩm/đơn</div>
          </div>
        </div>

        <!-- Top qty + top revenue charts -->
        <div class="grid-2">
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.top_qty">Top sản phẩm bán chạy</h3>
                <p data-i18n="chart.by_qty">Theo số lượng</p>
              </div>
            </div>
            <div class="chart-wrap" style="height:260px">
              <canvas id="chartTopQty"></canvas>
            </div>
          </div>
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.top_revenue">Top sản phẩm doanh thu cao</h3>
                <p data-i18n="chart.by_revenue">Theo doanh thu</p>
              </div>
            </div>
            <div class="chart-wrap" style="height:260px">
              <canvas id="chartTopRev"></canvas>
            </div>
          </div>
        </div>

        <!-- Brand share analysis -->
        <div class="grid-2">
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.brand_qty_share">Tỉ trọng doanh số theo thương hiệu</h3>
                <p data-i18n="chart.brand_qty_share.sub">Số lượng bán ra, gom theo 3 ký tự đầu SKU</p>
              </div>
            </div>
            <div class="chart-wrap" style="height:260px">
              <canvas id="chartBrandQtyShare"></canvas>
            </div>
          </div>
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.brand_revenue_share">Tỉ trọng doanh thu theo thương hiệu</h3>
                <p data-i18n="chart.brand_revenue_share.sub">Doanh thu sau giảm giá của đơn hoàn thành</p>
              </div>
            </div>
            <div class="chart-wrap" style="height:260px">
              <canvas id="chartBrandRevenueShare"></canvas>
            </div>
          </div>
        </div>

        <div class="card mb-4">
          <div class="card-title" style="margin-bottom:12px" data-i18n="card.brand_analysis">Phân tích thương hiệu</div>
          <div class="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th data-i18n="th.brand">Thương hiệu</th>
                  <th class="text-right">SKU</th>
                  <th class="text-right" data-i18n="th.qty_sold">SL bán</th>
                  <th class="text-right" data-i18n="th.qty_share">Tỉ trọng SL</th>
                  <th class="text-right" data-i18n="th.revenue">Doanh thu</th>
                  <th class="text-right" data-i18n="th.revenue_share">Tỉ trọng DT</th>
                </tr>
              </thead>
              <tbody id="brandShareTable"></tbody>
            </table>
          </div>
        </div>

        <!-- Mini bars + products table -->
        <div class="grid-3-1">
          <div class="card">
            <div class="card-title" data-i18n="card.product_list" style="margin-bottom:12px">Danh sách sản phẩm</div>
            <div class="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th data-i18n="th.sku">SKU</th>
                    <th data-i18n="th.product_name">Tên sản phẩm</th>
                    <th data-i18n="th.platform">Sàn</th>
                    <th class="text-right" data-i18n="th.qty">SL</th>
                    <th class="text-right" data-i18n="th.revenue">Doanh thu</th>
                  </tr>
                </thead>
                <tbody id="productsTable"></tbody>
              </table>
            </div>
            <div id="productsPager"></div>
          </div>
          <div class="card">
            <div class="card-title" data-i18n="card.top5_revenue" style="margin-bottom:12px">Top 5 doanh thu</div>
            <div id="topRevMini"></div>
          </div>
        </div>
      </div>

      <!-- ── Customers ─────────────────────────────────────────────────── -->
      <div class="page" id="page-customers">
        <div class="page-header">
          <h1 data-i18n="page.customers.title">Khách hàng</h1>
          <p data-i18n="page.customers.sub">Phân tích khách hàng theo địa lý và phương thức thanh toán</p>
        </div>

        <div class="grid-4 mb-4">
          <div class="kpi-card border-blue">
            <div class="kpi-label" data-i18n="kpi.total_orders">Tổng đơn</div>
            <div class="kpi-value" id="cust-total">—</div>
          </div>
          <div class="kpi-card border-green">
            <div class="kpi-label" data-i18n="kpi.aov">AOV</div>
            <div class="kpi-value" id="cust-aov">—</div>
            <div class="kpi-sub" data-i18n="kpi.aov.sub">Giá trị trung bình/đơn</div>
          </div>
          <div class="kpi-card border-purple">
            <div class="kpi-label" data-i18n="kpi.buyers">Người mua</div>
            <div class="kpi-value" id="cust-buyers">—</div>
            <div class="kpi-sub" data-i18n="kpi.buyers.sub">Người mua khác nhau</div>
          </div>
          <div class="kpi-card border-orange">
            <div class="kpi-label" data-i18n="kpi.conv_rate">Tỉ lệ chuyển đổi</div>
            <div class="kpi-value" id="cust-conv">—</div>
            <div class="kpi-sub" data-i18n="kpi.conv_rate.sub">Đơn / lượt truy cập</div>
          </div>
        </div>

        <div class="grid-2 mb-4">
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.customer_segments">Phân loại khách hàng</h3>
                <p data-i18n="chart.customer_segments.sub">Mới · Cũ · Tiềm năng</p>
              </div>
            </div>
            <div class="donut-wrap" style="height:220px">
              <canvas id="chartCustomerSegments"></canvas>
              <div class="donut-center">
                <div class="donut-center-value" id="custSegTotal">—</div>
                <div class="donut-center-label" data-i18n="seg.total_label">Người mua</div>
              </div>
            </div>
            <div class="chart-legend" id="custSegLegend"></div>
          </div>
          <div class="card">
            <div class="card-title" data-i18n="card.top_locations" style="margin-bottom:4px">Top địa phương</div>
            <p style="font-size:11px;color:var(--text-muted);margin-bottom:12px" data-i18n="cl.location_note">Chỉ tính Shopee &amp; TikTok Shop — Lazada không có thông tin địa chỉ</p>
            <div id="cityList"></div>
            <div id="cityListPager"></div>
          </div>
        </div>

        <div class="card customer-leaderboard-card mb-4">
          <div class="chart-header customer-leaderboard-header">
            <div class="chart-header-left">
              <h3 data-i18n="card.customer_leaderboard">Khách hàng nổi bật</h3>
              <p data-i18n="card.customer_leaderboard.sub">Thống kê theo username trong bộ lọc hiện tại</p>
            </div>
          </div>
          <div class="table-wrapper customer-leaderboard-table">
            <table>
              <thead>
                <tr>
                  <th style="width:64px" data-i18n="th.rank">Hạng</th>
                  <th data-i18n="th.username">Username</th>
                  <th class="text-right" data-i18n="cl.orders">Đơn hàng</th>
                  <th class="text-right" data-i18n="cl.quantity">Số lượng</th>
                  <th class="text-right" data-i18n="th.revenue">Doanh thu</th>
                </tr>
              </thead>
              <tbody id="customerStatsTable"></tbody>
            </table>
          </div>
        </div>

        <!-- District breakdown -->
        <div class="grid-2 mt-4">
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.hcm_districts">Quận / Huyện — TP. Hồ Chí Minh</h3>
                <p>Shopee &amp; TikTok Shop</p>
              </div>
            </div>
            <div class="chart-wrap" style="height:320px">
              <canvas id="chartHcmDistricts"></canvas>
            </div>
          </div>
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.hanoi_districts">Quận / Huyện — Hà Nội</h3>
                <p>Shopee &amp; TikTok Shop</p>
              </div>
            </div>
            <div class="chart-wrap" style="height:320px">
              <canvas id="chartHanoiDistricts"></canvas>
            </div>
          </div>
        </div>
      </div>

      <!-- ── Traffic ───────────────────────────────────────────────────── -->
      <div class="page" id="page-traffic">
        <div class="page-header">
          <h1 data-i18n="page.traffic.title">Lượng truy cập</h1>
          <p data-i18n="page.traffic.sub">Lượt xem, lượt truy cập và tỷ lệ chuyển đổi</p>
        </div>

        <div class="grid-4 mb-4">
          <div class="kpi-card border-blue">
            <div class="kpi-label" data-i18n="kpi.traffic_views">Lượt xem</div>
            <div class="kpi-value" id="tr-views">—</div>
          </div>
          <div class="kpi-card border-green">
            <div class="kpi-label" data-i18n="kpi.visits">Lượt truy cập</div>
            <div class="kpi-value" id="tr-visits">—</div>
          </div>
          <div class="kpi-card border-orange">
            <div class="kpi-label" data-i18n="kpi.bounce_rate">Tỷ lệ thoát TB</div>
            <div class="kpi-value" id="tr-bounce">—</div>
          </div>
        </div>

        <div class="mb-4">
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.traffic_trend">Traffic theo thời gian</h3>
                <p data-i18n="chart.traffic_trend.sub">Lượt xem + đơn hàng tương quan</p>
              </div>
            </div>
            <div class="chart-wrap" style="height:220px">
              <canvas id="chartTrafficTrend"></canvas>
            </div>
          </div>
        </div>

        <div class="grid-2">
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="chart.traffic_platform">Traffic theo sàn</h3>
              </div>
            </div>
            <div class="chart-wrap" style="height:180px">
              <canvas id="chartTrafficPlatform"></canvas>
            </div>
          </div>
        </div>
      </div>

      <!-- ── Comparison ────────────────────────────────────────────────── -->
      <div class="page" id="page-comparison">
        <div class="page-header">
          <h1 data-i18n="page.comparison.title">So sánh sàn</h1>
          <p data-i18n="page.comparison.sub">Hiệu suất Shopee, Lazada và TikTok Shop</p>
        </div>

        <!-- Platform stat cards -->
        <div class="grid-3 mb-4">
          <?php foreach (['shopee','lazada','tiktokshop'] as $p): ?>
          <div class="platform-card <?= $p ?>" id="platform-card-<?= $p ?>">
            <div class="platform-card-header">
              <span class="badge badge-<?= $p ?>"><?= $p === 'tiktokshop' ? 'TikTok Shop' : ucfirst($p) ?></span>
            </div>
            <div class="platform-stat-row"><span class="platform-stat-label" data-i18n="compare.orders">Tổng đơn</span><span class="platform-stat-value pc-orders">—</span></div>
            <div class="platform-stat-row"><span class="platform-stat-label" data-i18n="compare.completed">Hoàn thành</span><span class="platform-stat-value pc-completed">—</span></div>
            <div class="platform-stat-row"><span class="platform-stat-label" data-i18n="compare.revenue">Doanh thu</span><span class="platform-stat-value pc-revenue">—</span></div>
            <div class="platform-stat-row"><span class="platform-stat-label" data-i18n="compare.share">Thị phần</span><span class="platform-stat-value pc-share">—</span></div>
            <div class="platform-stat-row"><span class="platform-stat-label" data-i18n="compare.aov">AOV</span><span class="platform-stat-value pc-aov">—</span></div>
            <div class="platform-stat-row"><span class="platform-stat-label" data-i18n="compare.cancel">Tỷ lệ huỷ</span><span class="platform-stat-value pc-cancel">—</span></div>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- Compare charts -->
        <div class="grid-3">
          <div class="chart-card">
            <div class="chart-header"><div class="chart-header-left"><h3 data-i18n="kpi.revenue">Doanh thu</h3></div></div>
            <div class="chart-wrap" style="height:180px"><canvas id="chartCompareRevenue"></canvas></div>
          </div>
          <div class="chart-card">
            <div class="chart-header"><div class="chart-header-left"><h3 data-i18n="kpi.orders">Đơn hàng</h3></div></div>
            <div class="chart-wrap" style="height:180px"><canvas id="chartCompareOrders"></canvas></div>
          </div>
          <div class="chart-card">
            <div class="chart-header"><div class="chart-header-left"><h3 data-i18n="chart.radar">Radar tổng hợp</h3></div></div>
            <div class="chart-wrap" style="height:180px"><canvas id="chartRadar"></canvas></div>
          </div>
        </div>

        <!-- Top products table -->
        <div class="card">
          <div class="card-title" style="margin-bottom:10px" data-i18n="compare.top5">Top 5 sản phẩm mỗi sàn</div>
          <div class="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Shopee</th>
                  <th>Lazada</th>
                  <th>TikTok Shop</th>
                </tr>
              </thead>
              <tbody id="comparisonTable"></tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- ── Plan ──────────────────────────────────────────────────────── -->
      <div class="page" id="page-plan">
        <div class="page-header plan-page-header">
          <div>
            <h1 data-i18n="page.plan.title">Kế hoạch</h1>
            <p data-i18n="page.plan.sub">Theo dõi Target YTD, YTG và run-rate cần đạt mục tiêu năm</p>
          </div>
          <div class="plan-year-pill" id="planYearPill">FY —</div>
        </div>

        <div class="card plan-ytg-card mb-4">
          <div class="card-title" data-i18n="plan.progress.title">Tiến độ hiện tại</div>
          <div class="card-subtitle" data-i18n="plan.progress.sub">Tiến độ chuẩn hóa theo % để so sánh giữa các chỉ tiêu có quy mô khác nhau.</div>
          <div id="planYtgProgress" class="plan-ytg-progress plan-ytg-progress-cols">
            <div class="plan-empty-cell" data-i18n="msg.loading">Đang tải...</div>
          </div>
        </div>

        <div class="card plan-target-card mb-4">
          <div class="plan-card-head">
            <div>
              <div class="card-title" data-i18n="plan.target_table.title">Target YTD / YTG</div>
              <div class="card-subtitle" data-i18n="plan.target_table.sub">Bảng điều hành nhanh theo mục tiêu năm, thực đạt hiện tại và mức trung bình cần đạt cho các tháng còn lại.</div>
            </div>
            <span class="plan-updated" id="planUpdatedAt">—</span>
          </div>
          <div class="table-wrapper plan-target-table-wrap">
            <table class="plan-target-table plan-target-summary">
              <thead>
                <tr>
                  <th class="plan-col-metric" data-i18n="plan.th.metric">Chỉ tiêu</th>
                  <th class="text-right">Target FY</th>
                  <th class="text-right">Target YTD</th>
                  <th class="text-right">Actual YTD</th>
                  <th class="text-right">% YTD</th>
                  <th class="text-right">Gap YTD</th>
                  <th class="text-right">YTG</th>
                  <th class="text-right" data-i18n="plan.th.avg_remaining">TB/tháng còn lại</th>
                  <th data-i18n="plan.th.status">Trạng thái</th>
                </tr>
              </thead>
              <tbody id="planTargetTableBody">
                <tr><td colspan="9" class="plan-empty-cell" data-i18n="plan.loading">Đang tải kế hoạch...</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="card plan-target-card mb-4">
          <div class="plan-card-head">
            <div>
              <div class="card-title" data-i18n="plan.monthly.title">Chi tiết theo tháng</div>
              <div class="card-subtitle" data-i18n="plan.monthly.sub">Thực đạt từng tháng so với mục tiêu trung bình tháng (Target FY / 12).</div>
            </div>
          </div>
          <div class="table-wrapper plan-target-table-wrap">
            <table class="plan-target-table plan-target-monthly">
              <thead>
                <tr>
                  <th class="plan-col-metric" data-i18n="plan.th.metric">Chỉ tiêu</th>
                  <th class="text-right plan-col-month">T1</th>
                  <th class="text-right plan-col-month">T2</th>
                  <th class="text-right plan-col-month">T3</th>
                  <th class="text-right plan-col-month">T4</th>
                  <th class="text-right plan-col-month">T5</th>
                  <th class="text-right plan-col-month">T6</th>
                  <th class="text-right plan-col-month">T7</th>
                  <th class="text-right plan-col-month">T8</th>
                  <th class="text-right plan-col-month">T9</th>
                  <th class="text-right plan-col-month">T10</th>
                  <th class="text-right plan-col-month">T11</th>
                  <th class="text-right plan-col-month">T12</th>
                </tr>
              </thead>
              <tbody id="planMonthlyTableBody">
                <tr><td colspan="13" class="plan-empty-cell" data-i18n="plan.monthly.loading">Đang tải dữ liệu tháng...</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="grid-3-1 plan-workbench">
          <div class="chart-card">
            <div class="chart-header">
              <div class="chart-header-left">
                <h3 data-i18n="plan.chart.run_rate">Tiến độ theo tháng</h3>
                <p data-i18n="plan.chart.run_rate.sub">Actual so với đường target bình quân năm</p>
              </div>
            </div>
            <div class="chart-wrap" style="height:300px">
              <canvas id="chartPlanRunRate"></canvas>
            </div>
          </div>
          <div class="card plan-form-card">
            <div class="card-title" data-i18n="plan.form.title">Mục tiêu năm</div>
            <div class="card-subtitle" data-i18n="plan.form.sub">Nhập mục tiêu doanh số và lượt truy cập cho năm đang xem.</div>
            <form id="planTargetForm" class="plan-target-form">
              <label>
                <span data-i18n="plan.form.year">Năm</span>
                <input id="planYearInput" type="number" min="2020" max="2100" step="1">
              </label>
              <label>
                <span data-i18n="plan.form.revenue_target">Doanh số mục tiêu</span>
                <input id="planRevenueTarget" type="number" min="0" step="1000000" inputmode="numeric" placeholder="VD: 2500000000">
              </label>
              <label>
                <span data-i18n="plan.form.visits_target">Lượt truy cập mục tiêu</span>
                <input id="planVisitsTarget" type="number" min="0" step="1000" inputmode="numeric" placeholder="VD: 1200000">
              </label>
              <button class="btn btn-primary" type="submit" data-i18n="plan.form.save">Lưu mục tiêu</button>
            </form>
          </div>
        </div>

      </div>

      <!-- ── Danh sách sản phẩm (SKU lẻ) ─────────────────────────────── -->
      <div class="page" id="page-product-list">
        <div class="page-header">
          <div>
            <h1 data-i18n="page.product_list.title">Danh sách sản phẩm</h1>
            <p data-i18n="page.product_list.sub">Quản lý các SKU lẻ: mã, tên, thương hiệu và giá gốc. Dùng chung cho dashboard (toggle COMBO/SKU) và đối soát GBS.</p>
          </div>
        </div>

        <div class="card mb-4" id="reconcileSettingsCard">
          <div class="reconcile-settings-head">
            <div>
              <div class="card-title" style="margin-bottom:4px" data-i18n="reconcile.price.title">SKU lẻ</div>
              <div class="card-subtitle" data-i18n="reconcile.price.sub">Mã SKU đơn lẻ với tên, thương hiệu và giá gốc. Giá gốc dùng để phân bổ doanh thu khi tách combo về SKU đơn lẻ. Có thể thêm/sửa trực tiếp hoặc Import từ Excel.</div>
            </div>
            <div class="reconcile-settings-actions">
              <button class="btn btn-secondary btn-sm js-reload-reconcile" data-i18n="reconcile.btn.reload">Tải lại</button>
              <button class="btn btn-primary btn-sm js-save-reconcile" data-i18n="reconcile.btn.save">Lưu thay đổi</button>
            </div>
          </div>

          <div class="reconcile-settings-summary" id="reconcileSettingsSummary">
            <span class="reconcile-settings-chip" data-i18n="reconcile.loading">Đang tải dữ liệu...</span>
          </div>

          <section class="reconcile-settings-panel">
            <div class="reconcile-settings-panel-head">
              <div>
                <h3 data-i18n="reconcile.price.panel_title">Danh sách SKU lẻ</h3>
                <p data-i18n="reconcile.price.panel_sub">Mã SKU lẻ với tên, thương hiệu và giá gốc.</p>
              </div>
              <div class="reconcile-settings-panel-actions">
                <button class="btn btn-secondary btn-sm js-import-prices" title="Import lần đầu hoặc cập nhật hàng loạt từ Excel; dữ liệu được lưu vào database" data-i18n="reconcile.btn.import_excel" data-i18n-title="reconcile.btn.import_title">Import Excel</button>
                <button class="btn btn-primary btn-sm js-add-price-row" data-i18n="reconcile.btn.add_row">Thêm dòng</button>
              </div>
            </div>
            <div class="reconcile-settings-hint" data-i18n="reconcile.price.hint">Excel cần có cột: SKU, Tên sản phẩm, Thương hiệu (tuỳ chọn), Đơn giá.</div>
            <div class="table-wrapper">
              <table class="reconcile-settings-table">
                <thead>
                  <tr>
                    <th data-i18n="reconcile.th.single_sku">SKU lẻ</th>
                    <th data-i18n="reconcile.th.product_name">Tên sản phẩm</th>
                    <th data-i18n="reconcile.th.brand">Thương hiệu</th>
                    <th class="text-right" data-i18n="reconcile.th.unit_price">Đơn giá</th>
                    <th data-i18n="reconcile.th.actions">Thao tác</th>
                  </tr>
                </thead>
                <tbody id="reconcilePriceTableBody">
                  <tr><td colspan="5" class="reconcile-settings-empty" data-i18n="reconcile.loading">Đang tải dữ liệu...</td></tr>
                </tbody>
              </table>
            </div>
          </section>

          <div id="reconcileSettingsResult" class="reconcile-settings-result" aria-live="polite"></div>

          <input type="file" id="reconcilePriceImportInput" accept=".xlsx,.xls" style="display:none">
        </div>
      </div>

      <!-- ── Liên kết dữ liệu sàn (COMBO ↔ SKU) ─────────────────────── -->
      <div class="page" id="page-data-link">
        <div class="page-header">
          <div>
            <h1 data-i18n="page.data_link.title">Liên kết dữ liệu sàn</h1>
            <p data-i18n="page.data_link.sub">Quy đổi SKU COMBO trên sàn về SKU lẻ thực tế. Dùng chung cho dashboard và đối soát GBS.</p>
          </div>
        </div>

        <div class="card mb-4" id="reconcileSettingsLinkCard">
          <div class="reconcile-settings-head">
            <div>
              <div class="card-title" style="margin-bottom:4px" data-i18n="reconcile.combo.title">Liên kết COMBO ↔ SKU</div>
              <div class="card-subtitle" data-i18n="reconcile.combo.sub">Một COMBO có thể quy đổi sang nhiều SKU lẻ khác nhau. Số lượng quy đổi dùng để bóc tách qty bán ra; doanh thu phân bổ theo tỉ lệ giá gốc × qty của từng SKU thành phần. Có thể thêm/sửa trực tiếp hoặc Import từ Excel.</div>
            </div>
            <div class="reconcile-settings-actions">
              <button class="btn btn-secondary btn-sm js-reload-reconcile" data-i18n="reconcile.btn.reload">Tải lại</button>
              <button class="btn btn-primary btn-sm js-save-reconcile" data-i18n="reconcile.btn.save">Lưu thay đổi</button>
            </div>
          </div>

          <div class="reconcile-settings-summary" id="reconcileSettingsLinkSummary">
            <span class="reconcile-settings-chip" data-i18n="reconcile.loading">Đang tải dữ liệu...</span>
          </div>

          <section class="reconcile-settings-panel">
            <div class="reconcile-settings-panel-head">
              <div>
                <h3 data-i18n="reconcile.combo.panel_title">Liên kết COMBO ↔ SKU</h3>
                <p data-i18n="reconcile.combo.panel_sub">Một SKU combo có thể liên kết nhiều SKU lẻ thực tế, mỗi SKU con có số lượng quy đổi riêng.</p>
              </div>
              <div class="reconcile-settings-panel-actions">
                <button class="btn btn-secondary btn-sm js-import-combos" title="Import lần đầu hoặc cập nhật hàng loạt từ Excel; dữ liệu được lưu vào database" data-i18n="reconcile.btn.import_excel" data-i18n-title="reconcile.btn.import_title">Import Excel</button>
                <button class="btn btn-primary btn-sm js-add-combo-row" data-i18n="reconcile.btn.add_combo">Thêm combo</button>
              </div>
            </div>
            <div class="reconcile-settings-hint" data-i18n="reconcile.combo.hint">Excel cần có cột: SKU Sản phẩm (combo), kèm các cặp Sản phẩm quy đổi N + Số lượng sản phẩm N.</div>
            <div class="table-wrapper">
              <table class="reconcile-settings-table">
                <thead>
                  <tr>
                    <th data-i18n="reconcile.th.platform">Sàn</th>
                    <th data-i18n="reconcile.th.combo_sku">SKU combo</th>
                    <th data-i18n="reconcile.th.combo_name">Tên / từ khóa combo</th>
                    <th data-i18n="reconcile.th.product_sku">SKU sản phẩm trong danh sách</th>
                    <th class="text-right" data-i18n="reconcile.th.qty_in_combo">SL trong combo</th>
                    <th data-i18n="reconcile.th.actions">Thao tác</th>
                  </tr>
                </thead>
                <tbody id="reconcileComboTableBody">
                  <tr><td colspan="6" class="reconcile-settings-empty" data-i18n="reconcile.loading">Đang tải dữ liệu...</td></tr>
                </tbody>
              </table>
              <datalist id="reconcileProductSkuOptions"></datalist>
            </div>
          </section>

          <div id="reconcileSettingsLinkResult" class="reconcile-settings-result" aria-live="polite"></div>

          <input type="file" id="reconcileComboImportInput" accept=".xlsx,.xls" style="display:none">
        </div>
      </div>

      <!-- ── GBS Reconciliation ───────────────────────────────────────── -->
      <div class="page" id="page-reconcile">
        <div class="page-header reconcile-page-header">
          <div class="reconcile-page-heading">
            <h1 data-i18n="page.reconcile.title">Đối soát GBS</h1>
            <p data-i18n="page.reconcile.sub">Đối soát GBS theo tháng với dữ liệu đơn hàng chung của Shopee, Lazada và TikTok Shop</p>
          </div>
          <div class="reconcile-page-actions">
            <button id="btnRefreshReconcile" class="btn btn-secondary">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 11a8.1 8.1 0 0 0-15.5-2M4 5v4h4"/><path d="M4 13a8.1 8.1 0 0 0 15.5 2M20 19v-4h-4"/></svg>
              <span data-i18n="btn.refresh">Làm mới</span>
            </button>
          </div>
        </div>
        <input id="reconcileFileInput" type="file" accept=".xlsx,.xls" style="display:none">

        <div class="reconcile-shell">
          <section class="card reconcile-upload-card">
            <div class="reconcile-section-head reconcile-section-head-compact">
              <div>
                <div class="reconcile-kicker" data-i18n="gbs.kicker.period">Kho GBS</div>
                <div class="card-title" data-i18n="gbs.upload.title">Upload file GBS theo tháng</div>
                <div class="card-subtitle" data-i18n="gbs.upload.sub">GBS quản lý riêng theo file tháng. Dữ liệu sàn lấy trực tiếp từ `orders`, không cần upload lại.</div>
              </div>
              <button type="button" class="btn" id="btnReconcileUploadPrimary">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5-5 5 5"/><path d="M12 5v12"/></svg>
                <span data-i18n="gbs.btn.add_file">Thêm file GBS</span>
              </button>
            </div>
            <div class="reconcile-upload-status" id="reconcileUploadStatus" data-i18n="gbs.upload.empty">Chưa có file GBS nào trong kho đối soát.</div>
            <div class="reconcile-source-grid">
              <div class="reconcile-source-chip">
                <span class="badge badge-gbs">GBS</span>
                <div>
                  <strong data-i18n="gbs.upload.note.file_month">File tháng</strong>
                  <span data-i18n="gbs.upload.note.file_month_desc">Tự nhận diện theo `Thời gian đối soát`, lưu nhiều file và xoá khi không còn dùng.</span>
                </div>
              </div>
              <div class="reconcile-source-chip">
                <span class="badge badge-shopee">Shopee</span>
                <div>
                  <strong data-i18n="gbs.upload.note.platform_source">Nguồn orders chung</strong>
                  <span data-i18n="gbs.upload.note.shopee_source">Khớp tháng theo `Thời gian hoàn thành đơn hàng`.</span>
                </div>
              </div>
              <div class="reconcile-source-chip">
                <span class="badge badge-lazada">Lazada</span>
                <div>
                  <strong data-i18n="gbs.upload.note.platform_source">Nguồn orders chung</strong>
                  <span data-i18n="gbs.upload.note.lazada_source">Khớp tháng theo `ttsSla` đã đồng bộ vào hệ thống.</span>
                </div>
              </div>
              <div class="reconcile-source-chip">
                <span class="badge badge-tiktokshop">TikTok Shop</span>
                <div>
                  <strong data-i18n="gbs.upload.note.match_key">Đối chiếu mã đơn</strong>
                  <span data-i18n="gbs.upload.note.match_key_desc">Hiện ưu tiên khớp theo mã đơn vì chưa có mốc thời gian ổn định.</span>
                </div>
              </div>
            </div>
          </section>

          <section class="card reconcile-control-card">
            <div class="reconcile-section-head reconcile-section-head-compact">
              <div>
                <div class="reconcile-kicker" data-i18n="gbs.kicker.period">Kỳ Đối Soát</div>
                <div class="card-title" data-i18n="gbs.period.title">Tháng đang xem</div>
                <div class="card-subtitle" data-i18n="gbs.period.sub">Chọn tháng GBS để xác nhận kỳ và xuất danh sách đơn lệch.</div>
              </div>
              <div class="reconcile-control-actions">
                <button id="btnToggleReconcileMonthConfirm" class="btn btn-secondary" disabled data-i18n="gbs.btn.confirm">Xác nhận tháng</button>
                <button id="btnExportReconcileUnmatched" class="btn btn-secondary" disabled data-i18n="gbs.btn.export">Xuất đơn chưa khớp</button>
              </div>
            </div>
            <div id="reconcileSelectedMonthMeta" class="reconcile-current-month">
              <span data-i18n="gbs.empty.no_months">Chưa có tháng đối soát nào sẵn sàng.</span>
            </div>
          </section>
        </div>

        <div class="card">
          <div class="reconcile-section-head">
            <div>
              <div class="reconcile-kicker" data-i18n="gbs.kicker.months">Các Kỳ GBS</div>
              <div class="card-title" data-i18n="gbs.months.title">Danh sách tháng GBS</div>
              <div class="card-subtitle" data-i18n="gbs.months.sub">Hệ thống tự gom tháng từ toàn bộ file GBS, chọn nhanh từng kỳ để đối soát.</div>
            </div>
            <div class="reconcile-managed-summary" id="reconcileManagedSummary" data-i18n="gbs.stat.zero_months">0 tháng</div>
          </div>
          <div class="reconcile-month-list" id="reconcileMonthList"></div>
        </div>

        <div class="card reconcile-hero-card">
          <div class="reconcile-hero-copy">
            <div class="reconcile-kicker" data-i18n="gbs.kicker.rules">Nguyên Tắc Khớp</div>
            <h3 data-i18n="gbs.rules.title">Đối soát GBS theo tháng trên cùng một nguồn dữ liệu đơn hàng</h3>
            <div class="reconcile-hero-points">
              <div class="reconcile-hero-point">
                <strong>NMV</strong>
                <span data-i18n="gbs.rules.shopee">Shopee khớp theo `Giá ưu đãi - Mã giảm giá của Shop` và chỉ trừ voucher shop 1 lần / đơn; GBS làm tròn tiền trước khi so sánh.</span>
              </div>
              <div class="reconcile-hero-point">
                <strong>Combo</strong>
                <span data-i18n="gbs.rules.combo">Quy đổi combo về SKU lẻ và phân bổ NMV bằng dữ liệu trong trang <strong>SKU & Combo</strong>.</span>
              </div>
              <div class="reconcile-hero-point">
                <strong data-i18n="gbs.rules.match_key">Khóa khớp</strong>
                <span data-i18n="gbs.rules.match_key_desc">Đối chiếu theo `platform + order_id`, ưu tiên dữ liệu orders chung để tránh upload trùng.</span>
              </div>
            </div>
          </div>
          <div class="reconcile-run-meta" id="reconcileRunMeta" data-i18n="gbs.run.not_loaded">Chưa tải dữ liệu đối soát.</div>
        </div>

        <div class="grid-4 reconcile-kpi-grid">
          <div class="kpi-card border-blue">
            <div class="kpi-label" data-i18n="gbs.kpi.platform_orders">Đơn sàn trong phạm vi</div>
            <div class="kpi-value" id="reconcile-stat-platform-orders">0</div>
            <div class="kpi-sub" data-i18n="gbs.kpi.platform_orders.sub">Dữ liệu lấy từ bảng orders theo logic thời gian của từng sàn</div>
          </div>
          <div class="kpi-card border-green">
            <div class="kpi-label" data-i18n="gbs.kpi.intersection">Đơn giao nhau</div>
            <div class="kpi-value" id="reconcile-stat-common-orders">0</div>
            <div class="kpi-sub" data-i18n="gbs.kpi.intersection.sub">Có mặt đồng thời trong GBS và dữ liệu sàn chung</div>
          </div>
          <div class="kpi-card border-teal">
            <div class="kpi-label" data-i18n="gbs.kpi.matched">Đơn khớp</div>
            <div class="kpi-value" id="reconcile-stat-matched-orders">0</div>
            <div class="kpi-sub" data-i18n="gbs.kpi.matched.sub">Khớp số lượng và NMV sau khi quy đổi</div>
          </div>
          <div class="kpi-card border-red">
            <div class="kpi-label" data-i18n="gbs.kpi.review">Đơn cần xem</div>
            <div class="kpi-value" id="reconcile-stat-review-orders">0</div>
            <div class="kpi-sub" data-i18n="gbs.kpi.review.sub">Bao gồm đơn thiếu ở một phía hoặc lệch sau đối chiếu</div>
          </div>
        </div>

        <div class="card">
          <div class="reconcile-section-head">
            <div>
              <div class="reconcile-kicker">Kho File</div>
              <div class="card-title" data-i18n="gbs.files.title">Quản lý file GBS</div>
              <div class="card-subtitle" data-i18n="gbs.files.sub">Theo dõi file đã upload, tháng nhận diện được và xoá từng file sau khi hoàn tất đối soát.</div>
            </div>
            <div class="reconcile-managed-summary" id="reconcileManagedFileCount">0 file</div>
          </div>
          <div class="table-wrapper">
            <table class="reconcile-table reconcile-managed-table">
              <thead>
                <tr>
                  <th>File GBS</th>
                  <th data-i18n="gbs.th.detected_month">Tháng nhận diện</th>
                  <th data-i18n="gbs.th.updated">Cập nhật</th>
                  <th class="text-right" data-i18n="gbs.th.size">Kích thước</th>
                  <th class="text-right" data-i18n="gbs.th.rows_orders">Dòng / Đơn</th>
                  <th data-i18n="gbs.th.actions">Thao tác</th>
                </tr>
              </thead>
              <tbody id="reconcileManagedFilesTable"></tbody>
            </table>
          </div>
        </div>

        <div class="card">
          <div class="reconcile-section-head">
            <div>
              <div class="reconcile-kicker" data-i18n="gbs.kicker.summary">Tổng Quan</div>
              <div class="card-title" data-i18n="gbs.summary.title">Tóm tắt theo sàn</div>
              <div class="card-subtitle" data-i18n="gbs.summary.sub">So sánh nhanh số lượng đơn GBS và orders chung theo từng sàn trong tháng đã chọn.</div>
            </div>
          </div>
          <div class="table-wrapper">
            <table class="reconcile-table reconcile-summary-table">
              <thead>
                <tr>
                  <th data-i18n="th.platform">Sàn</th>
                  <th data-i18n="gbs.th.platform_orders_col">Đơn sàn</th>
                  <th data-i18n="gbs.th.gbs_orders">Đơn GBS</th>
                  <th data-i18n="gbs.th.common_orders">Đơn chung</th>
                  <th data-i18n="gbs.th.matched_orders">Đơn khớp</th>
                  <th data-i18n="gbs.th.missing_in_gbs">Thiếu trong GBS</th>
                  <th data-i18n="gbs.th.missing_in_platform">Thiếu trong file sàn</th>
                </tr>
              </thead>
              <tbody id="reconcileSummaryBody"></tbody>
            </table>
          </div>
        </div>

        <div class="card">
          <div class="reconcile-section-head">
            <div>
              <div class="reconcile-kicker" data-i18n="gbs.unmatched.kicker">Cần Xử Lý</div>
              <div class="card-title" data-i18n="gbs.unmatched.title">Đơn sàn chưa khớp với GBS</div>
              <div class="card-subtitle" data-i18n="gbs.unmatched.sub">Gồm đơn thiếu ở GBS hoặc còn lệch số lượng / NMV. Có thể xuất toàn bộ danh sách theo tháng đang xem.</div>
            </div>
            <div class="reconcile-managed-summary" id="reconcileUnmatchedSummary" data-i18n="gbs.unmatched.zero">0 đơn</div>
          </div>
          <div class="table-wrapper">
            <table class="reconcile-table reconcile-unmatched-table">
              <thead>
                <tr>
                  <th data-i18n="th.platform">Sàn</th>
                  <th data-i18n="th.order_id">Mã đơn</th>
                  <th data-i18n="gbs.th.result">Kết quả</th>
                  <th data-i18n="gbs.th.platform_time">Thời gian sàn</th>
                  <th data-i18n="gbs.th.platform_qty_nmv">SL / NMV sàn</th>
                  <th data-i18n="gbs.th.gbs_qty_nmv">SL / NMV GBS</th>
                  <th data-i18n="gbs.th.note">Ghi chú</th>
                </tr>
              </thead>
              <tbody id="reconcileUnmatchedBody"></tbody>
            </table>
          </div>
        </div>

        <details class="card reconcile-disclosure">
          <summary class="reconcile-disclosure-head">
            <div>
              <div class="reconcile-kicker" data-i18n="gbs.mapping.kicker">Quy Tắc Dữ Liệu</div>
              <div class="card-title" data-i18n="gbs.mapping.title">Quy tắc đối soát theo sàn</div>
              <div class="card-subtitle" data-i18n="gbs.mapping.sub">Mở ra khi cần kiểm tra cách GBS được quy đổi và khớp với dữ liệu orders chung.</div>
            </div>
            <span class="reconcile-disclosure-label" data-i18n="gbs.mapping.view_detail">Xem chi tiết</span>
          </summary>
          <div class="reconcile-disclosure-body">
            <div class="reconcile-map-grid" id="reconcileMappings"></div>
          </div>
        </details>

        <div class="card">
          <div class="reconcile-section-head">
            <div>
              <div class="reconcile-kicker" data-i18n="gbs.platform.kicker">Chi Tiết Theo Sàn</div>
              <div class="card-title" data-i18n="gbs.platform.title">Bảng đối chiếu chi tiết</div>
              <div class="card-subtitle" data-i18n="gbs.platform.sub">Mỗi sàn được thu gọn riêng để giảm chiều dài trang và tập trung vào các phần có chênh lệch.</div>
            </div>
          </div>
          <div class="reconcile-platform-sections" id="reconcilePlatformSections"></div>
        </div>
      </div>

      <!-- ── Heatmaps ──────────────────────────────────────────────────── -->
      <div class="page" id="page-heatmaps">
        <div class="page-header">
          <h1 data-i18n="page.analytics.title">Phân tích nâng cao</h1>
          <p data-i18n="page.analytics.sub">Heatmap thời gian đặt hàng, doanh thu theo địa lý, sản phẩm và thương hiệu</p>
        </div>

        <div class="analytics-filter-card">
          <div class="analytics-filter-head">
            <div>
              <div class="card-title" data-i18n="analytics.filters.title">Bộ lọc phân tích</div>
              <div class="card-subtitle" data-i18n="analytics.filters.sub">Lọc riêng heatmap và biểu đồ địa phương theo SKU sản phẩm hoặc thương hiệu.</div>
            </div>
            <button id="btnClearAnalyticsFilters" class="btn btn-secondary btn-sm" data-i18n="analytics.filters.clear">Xóa lọc</button>
          </div>
          <div class="analytics-filter-grid">
            <label class="analytics-filter-field">
              <span data-i18n="th.product">Sản phẩm</span>
              <select id="analyticsProductFilter">
                <option value="" data-i18n="filter.all_products">Tất cả sản phẩm</option>
              </select>
            </label>
            <label class="analytics-filter-field">
              <span data-i18n="th.brand">Thương hiệu</span>
              <select id="analyticsBrandFilter">
                <option value="" data-i18n="filter.all_brands">Tất cả thương hiệu</option>
              </select>
            </label>
            <div class="analytics-filter-summary" id="analyticsFilterSummary" data-i18n="msg.loading">Đang tải...</div>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">

          <!-- Heatmap đơn hàng -->
          <div class="card" style="min-width:0">
            <div class="card-title" data-i18n="card.orders_heatmap">Đơn hàng theo ngày &amp; giờ</div>
            <div style="display:flex;align-items:center;gap:4px;margin-bottom:10px;flex-wrap:wrap">
              <span data-i18n="common.low" style="font-size:11px;color:var(--text-muted)">Ít</span>
              <?php foreach (['#f1f5f9','#dbeafe','#bfdbfe','#93c5fd','#60a5fa','#3b82f6','#2563eb','#1d4ed8','#1e3a8a','#172554','#0f1629'] as $c): ?>
              <span style="width:14px;height:14px;border-radius:2px;background:<?= htmlspecialchars($c) ?>;display:inline-block"></span>
              <?php endforeach; ?>
              <span data-i18n="common.high" style="font-size:11px;color:var(--text-muted)">Nhiều</span>
            </div>
            <div class="heatmap-container">
              <div id="heatmap7x24"></div>
            </div>
          </div>

          <!-- Heatmap doanh thu -->
          <div class="card" style="min-width:0">
            <div class="card-title" data-i18n="card.rev_heatmap">Doanh thu theo ngày &amp; giờ</div>
            <div style="display:flex;align-items:center;gap:4px;margin-bottom:10px;flex-wrap:wrap">
              <span data-i18n="common.low" style="font-size:11px;color:var(--text-muted)">Ít</span>
              <?php foreach (['#f0fdf4','#dcfce7','#bbf7d0','#86efac','#4ade80','#22c55e','#16a34a','#15803d','#166534','#14532d','#052e16'] as $c): ?>
              <span style="width:14px;height:14px;border-radius:2px;background:<?= htmlspecialchars($c) ?>;display:inline-block"></span>
              <?php endforeach; ?>
              <span data-i18n="common.high" style="font-size:11px;color:var(--text-muted)">Nhiều</span>
            </div>
            <div class="heatmap-container">
              <div id="heatmapRevenue7x24"></div>
            </div>
          </div>

        </div>

        <div class="chart-card">
          <div class="chart-header">
            <div class="chart-header-left">
              <h3 data-i18n="chart.revenue_city">Doanh thu theo tỉnh / thành</h3>
              <p data-i18n="chart.top15">Top 15 địa phương</p>
            </div>
          </div>
          <div class="chart-wrap" style="height:340px">
            <canvas id="chartRevenueCity"></canvas>
          </div>
        </div>
      </div>

      <!-- ── Upload ────────────────────────────────────────────────────── -->
      <div class="page" id="page-upload">
        <div class="page-header">
          <h1 data-i18n="page.upload.title">Upload dữ liệu</h1>
          <p data-i18n="page.upload.sub">Tải lên file Excel từ Shopee, Lazada, TikTok Shop</p>
        </div>

        <div class="grid-3-1">
          <div class="card">
            <!-- Drop zone -->
            <div class="upload-area" id="uploadArea">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/>
              </svg>
              <div class="upload-area-title" data-i18n="upload.area.title">Kéo thả file vào đây</div>
              <div class="upload-area-sub" data-i18n-html="upload.area.sub">hoặc <span id="browseBtn">chọn file</span> từ máy tính</div>
              <div class="upload-area-hint" data-i18n="upload.area.hint">Hỗ trợ .xlsx và .xls — nhiều file cùng lúc, tự nhận diện đúng mẫu traffic Shopee / Lazada / TikTok Shop khi upload</div>
              <input id="fileInput" type="file" accept=".xlsx,.xls" multiple style="display:none">
            </div>

            <!-- File queue -->
            <div class="file-queue" id="fileQueue"></div>

            <!-- Actions -->
            <div class="upload-actions">
              <button id="btnUpload" class="btn btn-primary btn-sm" disabled>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
                <span data-i18n="upload.btn_upload">Tải lên</span>
              </button>
              <button id="btnClear" class="btn btn-secondary btn-sm" data-i18n="upload.clear_done">Xoá đã xong</button>
            </div>

            <!-- Results -->
            <div class="file-queue" id="uploadResults" style="margin-top:20px"></div>
          </div>

          <div class="card">
            <div class="card-title" data-i18n="upload.guide.title">Hướng dẫn</div>
            <div class="card-subtitle" data-i18n="upload.guide.sub">Hệ thống tự động nhận diện sàn và loại dữ liệu</div>
            <div style="font-size:12px;color:var(--text-secondary);line-height:1.7">
              <p style="margin-bottom:8px"><strong data-i18n="upload.guide.platforms">Sàn được hỗ trợ:</strong></p>
              <ul style="padding-left:16px;margin-bottom:12px">
                <li data-i18n="upload.guide.shopee">Shopee — file xuất từ Seller Centre</li>
                <li>Lazada — file Orders export</li>
                <li>TikTok Shop — Order Management export</li>
              </ul>
              <p style="margin-bottom:8px"><strong data-i18n="upload.guide.file_types">Loại file:</strong></p>
              <ul style="padding-left:16px;margin-bottom:12px">
                <li data-i18n-html="upload.guide.orders"><strong>Orders</strong> — dữ liệu đơn hàng</li>
                <li data-i18n-html="upload.guide.traffic"><strong>Traffic</strong> — lượt xem, lượt truy cập</li>
              </ul>
              <p style="margin-bottom:8px"><strong data-i18n="upload.guide.notes">Lưu ý:</strong></p>
              <ul style="padding-left:16px">
                <li data-i18n="upload.guide.max_size">File tối đa 50MB mỗi file</li>
                <li data-i18n="upload.guide.upsert">Dữ liệu trùng sẽ được cập nhật (upsert)</li>
                <li data-i18n="upload.guide.cleanup">File sẽ bị xoá sau khi xử lý</li>
              </ul>
            </div>
          </div>
        </div>

        <!-- Upload history -->
        <div class="card" style="margin-top:16px">
          <div class="card-title" data-i18n="upload.history.title">Lịch sử upload</div>
          <div class="table-wrapper" style="margin-top:10px">
            <table>
              <thead>
                <tr>
                  <th data-i18n="th.time">Thời gian</th>
                  <th data-i18n="th.platform">Sàn</th>
                  <th data-i18n="th.type">Loại</th>
                  <th data-i18n="th.file">File</th>
                  <th class="text-right" data-i18n="th.imported">Đã import</th>
                  <th class="text-right" data-i18n="th.skipped">Bỏ qua</th>
                  <th data-i18n="th.status">Trạng thái</th>
                </tr>
              </thead>
              <tbody id="uploadHistoryTable"></tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- ── Logs ────────────────────────────────────────────────────── -->
      <div class="page" id="page-logs">
        <div class="page-header">
          <h1 data-i18n="page.logs.title">Nhật ký hoạt động</h1>
          <p data-i18n="page.logs.sub">Tất cả sự kiện và lỗi được ghi lại tự động</p>
        </div>

        <!-- Stats row -->
        <div class="grid-5 mb-4" id="logStats">
          <div class="kpi-card border-blue">  <div class="kpi-label" data-i18n="msg.all">Tất cả</div>  <div class="kpi-value" id="log-stat-all">—</div></div>
          <div class="kpi-card border-green"> <div class="kpi-label">Info</div>    <div class="kpi-value" id="log-stat-info">—</div></div>
          <div class="kpi-card border-orange"><div class="kpi-label">Warning</div> <div class="kpi-value" id="log-stat-warning">—</div></div>
          <div class="kpi-card border-red">   <div class="kpi-label">Error</div>   <div class="kpi-value" id="log-stat-error">—</div></div>
          <div class="kpi-card border-purple"><div class="kpi-label">Critical</div><div class="kpi-value" id="log-stat-critical">—</div></div>
        </div>

        <div class="card">
          <!-- Filter bar -->
          <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:16px">
            <select id="logFilterLevel" style="height:34px;padding:0 10px;border:1px solid var(--border);border-radius:6px;background:var(--bg-card);color:var(--text-primary);font-size:13px">
              <option value="" data-i18n="log.all_levels">Tất cả mức</option>
              <option value="debug">Debug</option>
              <option value="info">Info</option>
              <option value="warning">Warning</option>
              <option value="error">Error</option>
              <option value="critical">Critical</option>
            </select>
            <select id="logFilterCategory" style="height:34px;padding:0 10px;border:1px solid var(--border);border-radius:6px;background:var(--bg-card);color:var(--text-primary);font-size:13px">
              <option value="" data-i18n="log.all_categories">Tất cả danh mục</option>
              <option value="auth">Auth</option>
              <option value="upload">Upload</option>
              <option value="api">API</option>
              <option value="admin">Admin</option>
              <option value="tiktok">TikTok</option>
              <option value="lazada">Lazada</option>
              <option value="app">App</option>
            </select>
            <input id="logSearch" type="text" placeholder="Tìm kiếm..." data-i18n-placeholder="log.search" style="height:34px;padding:0 10px;border:1px solid var(--border);border-radius:6px;background:var(--bg-card);color:var(--text-primary);font-size:13px;flex:1;min-width:180px">
            <button id="btnLogRefresh" class="btn btn-secondary btn-sm icon-only-btn" type="button" title="Làm mới" aria-label="Làm mới" data-i18n-title="btn.refresh">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.13-3.36L23 10M1 14l5.36 4.36A9 9 0 0020.49 15"/></svg>
            </button>
            <button id="btnLogClear" class="btn btn-sm" style="background:var(--red,#ef4444);color:#fff;border:none;padding:0 14px;height:34px;border-radius:6px;cursor:pointer;font-size:13px" data-i18n="log.clear">Xoá log</button>
          </div>

          <!-- Table -->
          <div class="table-wrapper">
            <table id="logsTable">
              <thead>
                <tr>
                  <th style="width:140px" data-i18n="th.time">Thời gian</th>
                  <th style="width:80px" data-i18n="log.level">Mức</th>
                  <th style="width:80px" data-i18n="log.category">Danh mục</th>
                  <th data-i18n="log.message">Thông điệp</th>
                  <th style="width:80px">IP</th>
                  <th style="width:40px"></th>
                </tr>
              </thead>
              <tbody id="logsTableBody">
                <tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-muted)" data-i18n="msg.loading">Đang tải...</td></tr>
              </tbody>
            </table>
          </div>

          <!-- Pagination -->
          <div id="logsPagination" style="display:flex;gap:8px;justify-content:center;margin-top:16px;flex-wrap:wrap"></div>
        </div>
      </div>

      <!-- ── Admin ───────────────────────────────────────────────────── -->
      <div class="page" id="page-admin">
        <div class="page-header">
          <h1 data-i18n="page.admin.title">Quản trị hệ thống</h1>
          <p data-i18n="page.admin.sub">Quản lý tài khoản đăng nhập, cấu hình API và cài đặt vận hành</p>
        </div>

        <div class="admin-shell">
          <div class="admin-hero">
            <div class="admin-hero-title">
              <h2 data-i18n="admin.hero.title">Trung tâm điều phối quản trị</h2>
              <div class="admin-status-pill" id="adminHeroRole">Admin</div>
            </div>
            <p data-i18n="admin.hero.sub">Tất cả các thay đổi nhạy cảm như tài khoản đăng nhập, kết nối API, cập nhật hệ thống và reset dữ liệu đều được gom về một bảng điều khiển quản trị duy nhất.</p>
          </div>

          <div class="grid-4">
            <div class="kpi-card border-blue">
              <div class="kpi-label" data-i18n="admin.stats.total_users">Tổng tài khoản</div>
              <div class="kpi-value" id="admin-total-users">—</div>
              <div class="kpi-sub" data-i18n="admin.stats.total_users.sub">Tất cả tài khoản đăng nhập</div>
            </div>
            <div class="kpi-card border-green">
              <div class="kpi-label" data-i18n="admin.stats.active_users">Đang hoạt động</div>
              <div class="kpi-value" id="admin-active-users">—</div>
              <div class="kpi-sub" data-i18n="admin.stats.active_users.sub">Có thể đăng nhập</div>
            </div>
            <div class="kpi-card border-purple">
              <div class="kpi-label" data-i18n="admin.stats.admins">Quản trị viên</div>
              <div class="kpi-value" id="admin-admin-users">—</div>
              <div class="kpi-sub" data-i18n="admin.stats.admins.sub">Có quyền cấu hình hệ thống</div>
            </div>
            <div class="kpi-card border-orange">
              <div class="kpi-label" data-i18n="admin.stats.last_login">Đăng nhập gần nhất</div>
              <div class="kpi-value" id="admin-last-login">—</div>
              <div class="kpi-sub" data-i18n="admin.stats.last_login.sub">Dấu mốc hoạt động mới nhất</div>
            </div>
          </div>

          <div class="admin-tabbar">
            <button class="admin-tab-btn active" id="btnAdminTabAccounts" data-admin-tab="accounts" type="button">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/></svg>
              <span data-i18n="admin.tab.accounts">Tài khoản</span>
            </button>
            <button class="admin-tab-btn" id="btnAdminTabApi" data-admin-tab="api" type="button">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
              <span data-i18n="admin.tab.api">API & kết nối</span>
            </button>
          </div>

          <div class="admin-tab-panel active" data-admin-tab-panel="accounts">
            <div class="admin-grid">
              <div class="admin-panel-card">
                <div class="admin-panel-head">
                  <div>
                    <h3 data-i18n="admin.users.title">Danh sách tài khoản đăng nhập</h3>
                    <p data-i18n="admin.users.sub">Tạo mới, phân quyền admin/staff và kiểm soát trạng thái hoạt động của từng tài khoản.</p>
                  </div>
                  <div class="admin-panel-actions">
                    <button class="btn btn-secondary btn-sm" id="btnAdminUserRefresh" data-i18n="admin.users.refresh">Làm mới</button>
                  </div>
                </div>
                <div class="table-wrapper">
                  <table class="admin-user-table">
                    <thead>
                      <tr>
                        <th data-i18n="admin.users.th.user">Tài khoản</th>
                        <th data-i18n="admin.users.th.role">Vai trò</th>
                        <th data-i18n="admin.users.th.status">Trạng thái</th>
                        <th data-i18n="admin.users.th.last_login">Lần đăng nhập cuối</th>
                        <th class="text-right" data-i18n="admin.users.th.actions">Thao tác</th>
                      </tr>
                    </thead>
                    <tbody id="adminUsersTableBody"></tbody>
                  </table>
                </div>
              </div>

              <div class="admin-panel-card">
                <div class="admin-panel-head">
                  <div>
                    <h3 id="adminUserFormMode" data-i18n="admin.form.create">Tạo tài khoản mới</h3>
                    <p data-i18n="admin.form.sub">Mỗi tài khoản staff có thể xem dashboard, chỉ admin mới truy cập được bảng quản trị này.</p>
                  </div>
                </div>

                <form class="admin-user-form" id="adminUserForm" autocomplete="off">
                  <input type="hidden" id="adminUserId">
                  <div class="admin-field">
                    <label for="adminUserUsername" data-i18n="admin.form.username">Tên đăng nhập</label>
                    <input id="adminUserUsername" type="text" placeholder="staff.analytics" required>
                  </div>

                  <div class="admin-field-grid">
                    <div class="admin-field">
                      <label for="adminUserFullName" data-i18n="admin.form.full_name">Tên hiển thị</label>
            <input id="adminUserFullName" type="text" placeholder="Nguyễn Văn A" data-i18n-placeholder="admin.form.full_name_placeholder">
                    </div>
                    <div class="admin-field">
                      <label for="adminUserRole" data-i18n="admin.form.role">Vai trò</label>
                      <select id="adminUserRole">
                        <option value="staff" data-i18n="admin.role.staff">Nhân viên</option>
                        <option value="admin" data-i18n="admin.role.admin">Quản trị viên</option>
                      </select>
                    </div>
                  </div>

                  <div class="admin-field">
                    <label for="adminUserPassword" data-i18n="admin.form.password">Mật khẩu</label>
            <input id="adminUserPassword" type="password" placeholder="Từ 8 ký tự, tối thiểu mức Trung bình" data-i18n-placeholder="admin.form.password_placeholder">
                    <div class="password-strength is-empty" id="adminUserPasswordStrength">
                      <div class="password-strength-bar"><span class="password-strength-fill"></span></div>
                      <div class="password-strength-meta">
                        <span class="password-strength-value" data-i18n="password.strength.empty">Chưa nhập mật khẩu</span>
                        <span class="password-strength-note" data-i18n="password.strength.minimum">Yêu cầu tối thiểu mức Trung bình</span>
                      </div>
                    </div>
                    <div class="password-strength-rules">
                      <span class="password-strength-rule" data-password-rule="length" data-i18n="password.rule.length">Từ 8 ký tự trở lên</span>
                      <span class="password-strength-rule" data-password-rule="variety" data-i18n="password.rule.variety">Ít nhất 2 nhóm ký tự: chữ, số hoặc ký tự đặc biệt</span>
                    </div>
                  </div>

                  <div class="admin-toggle">
                    <div>
                      <label for="adminUserActive" data-i18n="admin.form.active">Cho phép đăng nhập</label>
                      <small data-i18n="admin.form.active.sub">Tắt mục này để khóa tài khoản mà không cần xoá.</small>
                    </div>
                    <input id="adminUserActive" type="checkbox" checked>
                  </div>

                  <div class="admin-toggle">
                    <div>
                      <label for="adminUserMustChangePassword" data-i18n="admin.form.must_change_password">Buộc đổi mật khẩu ở lần đăng nhập kế tiếp</label>
                      <small data-i18n="admin.form.must_change_password.sub">Nên bật khi admin cấp mật khẩu tạm hoặc vừa reset mật khẩu cho user.</small>
                    </div>
                    <input id="adminUserMustChangePassword" type="checkbox" checked>
                  </div>

                  <div class="admin-form-actions">
                    <button class="btn btn-primary" id="btnAdminUserSubmit" type="submit" data-i18n="admin.form.submit_create">Tạo tài khoản</button>
                    <button class="btn btn-secondary" id="btnAdminUserReset" type="button" data-i18n="admin.form.reset">Đặt lại form</button>
                  </div>
                </form>

                <div class="admin-form-note" data-i18n="admin.form.note">Khi đang sửa tài khoản, ô mật khẩu có thể để trống để giữ nguyên mật khẩu cũ. Nếu đổi mật khẩu, mật khẩu mới phải đạt tối thiểu mức Trung bình.</div>
              </div>
            </div>
          </div>

          <div class="admin-tab-panel" data-admin-tab-panel="api">
            <div id="adminApiMount"></div>
          </div>
        </div>
      </div>

      <!-- ── Kết nối API ────────────────────────────────────────────────── -->
      <div class="page page-admin-template" id="page-connect" aria-hidden="true">
        <div class="page-header">
          <h1 data-i18n="page.connect.title">Kết nối API</h1>
          <p data-i18n="page.connect.sub">Tự động đồng bộ đơn hàng từ Shopee, TikTok Shop và Lazada qua Open Platform API</p>
        </div>

        <!-- Platform tabs -->
        <div style="display:flex;gap:8px;margin-bottom:20px;border-bottom:2px solid var(--border);padding-bottom:0">
          <button id="btnConnectTabShopee" class="connect-tab connect-tab-active" onclick="switchConnectTab('shopee')" style="padding:8px 20px;font-size:14px;font-weight:600;border:none;background:none;cursor:pointer;border-bottom:2px solid var(--primary,#4f46e5);margin-bottom:-2px;color:var(--primary,#4f46e5)">Shopee</button>
          <button id="btnConnectTabTiktok" class="connect-tab" onclick="switchConnectTab('tiktok')" style="padding:8px 20px;font-size:14px;font-weight:600;border:none;background:none;cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-2px;color:var(--text-muted)">TikTok Shop</button>
          <button id="btnConnectTabLazada" class="connect-tab" onclick="switchConnectTab('lazada')" style="padding:8px 20px;font-size:14px;font-weight:600;border:none;background:none;cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-2px;color:var(--text-muted)">Lazada</button>
        </div>

        <!-- ── Shopee Tab ─────────────────────────────────────────────────── -->
        <div id="connectTabShopee">
          <!-- Credentials card -->
          <div class="card mb-4">
            <div class="card-title" data-i18n="connect.shopee.credentials_title">Thông tin xác thực Shopee Open Platform App</div>
            <p style="color:var(--text-muted);font-size:13px;margin-bottom:16px" data-i18n-html="connect.shopee.credentials_sub">
              Đăng nhập <strong>open.shopee.com</strong> → My Apps → Create App để lấy Partner ID và Partner Key.
            </p>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;max-width:600px">
              <div>
                <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block" for="shopeePartnerId">Partner ID</label>
                <input id="shopeePartnerId" type="number" class="login-input" placeholder="Nhập Partner ID..." data-i18n-placeholder="connect.placeholder.partner_id" style="width:100%;margin-top:4px">
              </div>
              <div>
                <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block" for="shopeePartnerKey">Partner Key</label>
                <input id="shopeePartnerKey" type="password" class="login-input" placeholder="Nhập Partner Key..." data-i18n-placeholder="connect.placeholder.partner_key" style="width:100%;margin-top:4px">
              </div>
            </div>
            <div style="margin-top:12px;display:flex;gap:10px;align-items:center">
              <button id="btnShopeeSaveCredentials" class="btn btn-primary" data-i18n="connect.save_credentials">Lưu thông tin</button>
              <button id="btnConnectShopee" class="btn btn-secondary" style="display:flex;align-items:center;gap:6px">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
                <span data-i18n="connect.shopee.connect">Kết nối Shopee</span>
              </button>
              <span id="shopeeConnectStatus" style="font-size:13px;color:var(--text-muted)"></span>
            </div>
          </div>

          <!-- Connected shops -->
          <div class="card">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
              <div class="card-title" style="margin-bottom:0" data-i18n="connect.shopee.connected_title">Shop Shopee đã kết nối</div>
              <div style="display:flex;gap:8px">
                <button id="btnShopeeSyncAll" class="btn btn-primary btn-sm" style="display:flex;align-items:center;gap:6px">
                  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>
                  <span data-i18n="connect.sync_all">Đồng bộ tất cả</span>
                </button>
                <button id="btnShopeeRefresh" class="btn btn-secondary btn-sm" data-i18n="btn.refresh">Làm mới</button>
              </div>
            </div>
            <div class="table-wrapper">
              <table id="shopeeShopsTable">
                <thead>
                  <tr>
                    <th>Shop</th>
                    <th style="width:90px">Shop ID</th>
                    <th style="width:100px" data-i18n="th.status">Trạng thái</th>
                    <th style="width:140px" data-i18n="th.token_expires">Token hết hạn</th>
                    <th style="width:140px" data-i18n="th.last_synced">Đồng bộ lần cuối</th>
                    <th style="width:110px" data-i18n="th.from_date">Từ ngày</th>
                    <th style="width:120px" data-i18n="th.actions">Thao tác</th>
                  </tr>
                </thead>
                <tbody id="shopeeShopsTableBody">
                  <tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)" data-i18n="msg.loading">Đang tải...</td></tr>
                </tbody>
              </table>
            </div>
            <div id="shopeeSyncResults" style="margin-top:16px"></div>
          </div>

          <!-- How to guide -->
          <div class="card mt-4" style="background:var(--bg-base)">
            <div class="card-title" data-i18n="connect.guide.shopee">Hướng dẫn kết nối Shopee</div>
            <ol style="color:var(--text-secondary);font-size:13px;line-height:2;padding-left:20px">
              <li data-i18n-html="connect.shopee.step1">Đăng nhập <strong>open.shopee.com</strong> → <strong>My Apps → Create App</strong></li>
              <li data-i18n-html="connect.shopee.step2">Trong App Settings, thêm Redirect URL: <code id="shopeeOauthRedirectUri">—</code></li>
              <li data-i18n-html="connect.shopee.step3">Sao chép <strong>Partner ID</strong> và <strong>Partner Key</strong> rồi điền vào form trên</li>
              <li data-i18n-html="connect.shopee.step4">Nhấn <strong>Lưu thông tin</strong> rồi nhấn <strong>Kết nối Shopee</strong></li>
              <li data-i18n="connect.shopee.step5">Đăng nhập tài khoản Shopee Seller và cấp quyền cho app</li>
              <li data-i18n-html="connect.shopee.step6">Sau khi kết nối thành công, nhấn <strong>Đồng bộ</strong> để tải đơn hàng về</li>
            </ol>
          </div>
        </div><!-- /#connectTabShopee -->

        <!-- ── TikTok Tab ─────────────────────────────────────────────────── -->
        <div id="connectTabTiktok" style="display:none">
          <!-- Credentials card -->
          <div class="card mb-4">
            <div class="card-title" data-i18n="connect.tiktok.credentials_title">Thông tin xác thực TikTok Shop App</div>
            <p style="color:var(--text-muted);font-size:13px;margin-bottom:16px" data-i18n-html="connect.tiktok.credentials_sub">
              Tạo app tại <strong>TikTok Shop Partner Center</strong> → App &amp; Service → Create app &amp; service để lấy App Key và App Secret.
            </p>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;max-width:600px">
              <div>
                <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block" for="tiktokAppKey">App Key</label>
                <input id="tiktokAppKey" type="text" class="login-input" placeholder="Nhập App Key..." data-i18n-placeholder="connect.placeholder.app_key" style="width:100%;margin-top:4px">
              </div>
              <div>
                <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block" for="tiktokAppSecret">App Secret</label>
                <input id="tiktokAppSecret" type="password" class="login-input" placeholder="Nhập App Secret..." data-i18n-placeholder="connect.placeholder.app_secret" style="width:100%;margin-top:4px">
              </div>
            </div>
            <div style="margin-top:12px;display:flex;gap:10px;align-items:center">
              <button id="btnSaveCredentials" class="btn btn-primary" data-i18n="connect.save_credentials">Lưu thông tin</button>
              <button id="btnConnectTiktok" class="btn btn-secondary" style="display:flex;align-items:center;gap:6px">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
                <span data-i18n="connect.tiktok.connect">Kết nối TikTok Shop</span>
              </button>
              <span id="connectStatus" style="font-size:13px;color:var(--text-muted)"></span>
            </div>
          </div>

          <!-- Connected shops -->
          <div class="card">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
              <div class="card-title" style="margin-bottom:0" data-i18n="connect.tiktok.connected_title">Shop đã kết nối</div>
              <div style="display:flex;gap:8px">
                <button id="btnSyncAll" class="btn btn-primary btn-sm" style="display:flex;align-items:center;gap:6px">
                  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>
                  <span data-i18n="connect.sync_all">Đồng bộ tất cả</span>
                </button>
                <button id="btnRefreshShops" class="btn btn-secondary btn-sm" data-i18n="btn.refresh">Làm mới</button>
              </div>
            </div>
            <div id="shopsTableWrapper">
              <div class="table-wrapper">
                <table id="shopsTable">
                  <thead>
                    <tr>
                      <th>Shop</th>
                      <th style="width:80px" data-i18n="th.region">Khu vực</th>
                      <th style="width:100px" data-i18n="th.status">Trạng thái</th>
                      <th style="width:140px" data-i18n="th.token_expires">Token hết hạn</th>
                      <th style="width:140px" data-i18n="th.last_synced">Đồng bộ lần cuối</th>
                      <th style="width:110px" data-i18n="th.from_date">Từ ngày</th>
                      <th style="width:120px" data-i18n="th.actions">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody id="shopsTableBody">
                    <tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)" data-i18n="msg.loading">Đang tải...</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div id="syncResults" style="margin-top:16px"></div>
          </div>

          <!-- How to guide TikTok -->
          <div class="card mt-4" style="background:var(--bg-base)">
            <div class="card-title" data-i18n="connect.guide.tiktok">Hướng dẫn kết nối TikTok Shop</div>
            <ol style="color:var(--text-secondary);font-size:13px;line-height:2;padding-left:20px">
              <li data-i18n-html="connect.tiktok.step1">Đăng ký tài khoản <strong>TikTok Shop Partner Center</strong> tại <code>partner.tiktokshop.com</code></li>
              <li data-i18n-html="connect.tiktok.step2">Vào <strong>App &amp; Service → Create app &amp; service</strong>, tạo Custom App</li>
              <li data-i18n-html="connect.tiktok.step3">Trong phần cài đặt app, bật <strong>Enable API</strong> và nhập Redirect URL: <code id="oauthRedirectUri">—</code></li>
              <li data-i18n-html="connect.tiktok.step4">Sao chép <strong>App Key</strong> và <strong>App Secret</strong> rồi điền vào form trên</li>
              <li data-i18n-html="connect.tiktok.step5">Nhấn <strong>Lưu thông tin</strong> rồi nhấn <strong>Kết nối TikTok Shop</strong></li>
              <li data-i18n="connect.tiktok.step6">Đăng nhập tài khoản TikTok Shop và cấp quyền cho app</li>
              <li data-i18n-html="connect.tiktok.step7">Sau khi kết nối thành công, nhấn <strong>Đồng bộ</strong> để tải đơn hàng về</li>
            </ol>
          </div>
        </div><!-- /#connectTabTiktok -->

        <!-- ── Lazada Tab ──────────────────────────────────────────────────── -->
        <div id="connectTabLazada" style="display:none">
          <!-- Credentials card -->
          <div class="card mb-4">
            <div class="card-title" data-i18n="connect.lazada.credentials_title">Thông tin xác thực Lazada Open Platform App</div>
            <p style="color:var(--text-muted);font-size:13px;margin-bottom:16px" data-i18n-html="connect.lazada.credentials_sub">
              Đăng nhập <strong>open.lazada.com</strong> → App Console → Create App để lấy App Key và App Secret.
            </p>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;max-width:600px">
              <div>
                <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block" for="lazadaAppKey">App Key</label>
                <input id="lazadaAppKey" type="text" class="login-input" placeholder="Nhập App Key..." data-i18n-placeholder="connect.placeholder.app_key" style="width:100%;margin-top:4px">
              </div>
              <div>
                <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block" for="lazadaAppSecret">App Secret</label>
                <input id="lazadaAppSecret" type="password" class="login-input" placeholder="Nhập App Secret..." data-i18n-placeholder="connect.placeholder.app_secret" style="width:100%;margin-top:4px">
              </div>
            </div>
            <div style="margin-top:12px;display:flex;gap:10px;align-items:center">
              <button id="btnLazadaSaveCredentials" class="btn btn-primary" data-i18n="connect.save_credentials">Lưu thông tin</button>
              <button id="btnConnectLazada" class="btn btn-secondary" style="display:flex;align-items:center;gap:6px">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
                <span data-i18n="connect.lazada.connect">Kết nối Lazada</span>
              </button>
              <span id="lazadaConnectStatus" style="font-size:13px;color:var(--text-muted)"></span>
            </div>
          </div>

          <!-- Connected accounts -->
          <div class="card">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
              <div class="card-title" style="margin-bottom:0" data-i18n="connect.lazada.connected_title">Tài khoản Lazada đã kết nối</div>
              <div style="display:flex;gap:8px">
                <button id="btnLazadaSyncAll" class="btn btn-primary btn-sm" style="display:flex;align-items:center;gap:6px">
                  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>
                  <span data-i18n="connect.sync_all">Đồng bộ tất cả</span>
                </button>
                <button id="btnLazadaRefresh" class="btn btn-secondary btn-sm" data-i18n="btn.refresh">Làm mới</button>
              </div>
            </div>
            <div class="table-wrapper">
              <table id="lazadaAccountsTable">
                <thead>
                  <tr>
                    <th data-i18n="th.account">Tài khoản</th>
                    <th style="width:80px" data-i18n="th.country">Quốc gia</th>
                    <th style="width:100px" data-i18n="th.status">Trạng thái</th>
                    <th style="width:140px" data-i18n="th.token_expires">Token hết hạn</th>
                    <th style="width:140px" data-i18n="th.last_synced">Đồng bộ lần cuối</th>
                    <th style="width:110px" data-i18n="th.from_date">Từ ngày</th>
                    <th style="width:120px" data-i18n="th.actions">Thao tác</th>
                  </tr>
                </thead>
                <tbody id="lazadaAccountsTableBody">
                  <tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)" data-i18n="msg.loading">Đang tải...</td></tr>
                </tbody>
              </table>
            </div>
            <div id="lazadaSyncResults" style="margin-top:16px"></div>
          </div>

          <!-- How to guide Lazada -->
          <div class="card mt-4" style="background:var(--bg-base)">
            <div class="card-title" data-i18n="connect.guide.lazada">Hướng dẫn kết nối Lazada</div>
            <ol style="color:var(--text-secondary);font-size:13px;line-height:2;padding-left:20px">
              <li data-i18n-html="connect.lazada.step1">Đăng nhập <strong>open.lazada.com</strong> → <strong>App Console → Create App</strong></li>
              <li data-i18n-html="connect.lazada.step2">Trong phần App Settings, thêm Redirect URL: <code id="lazadaOauthRedirectUri">—</code></li>
              <li data-i18n-html="connect.lazada.step3">Sao chép <strong>App Key</strong> và <strong>App Secret</strong> rồi điền vào form trên</li>
              <li data-i18n-html="connect.lazada.step4">Nhấn <strong>Lưu thông tin</strong> rồi nhấn <strong>Kết nối Lazada</strong></li>
              <li data-i18n="connect.lazada.step5">Đăng nhập tài khoản Lazada Seller Center và cấp quyền cho app</li>
              <li data-i18n-html="connect.lazada.step6">Sau khi kết nối thành công, nhấn <strong>Đồng bộ</strong> để tải đơn hàng về</li>
            </ol>
          </div>
        </div><!-- /#connectTabLazada -->

      </div>

      <!-- ── Cài đặt ngôn ngữ (standalone page) ───────────────────────── -->
      <div class="page" id="page-settings-lang">
        <div class="page-header">
          <h1 data-i18n="page.settings_lang.title">Cài đặt ngôn ngữ</h1>
          <p data-i18n="page.settings_lang.sub">Quản lý các bộ ngôn ngữ hiển thị của giao diện.</p>
        </div>

        <div class="card mb-4" id="langSettingsCard">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
            <div class="card-title" style="margin-bottom:0" data-i18n="lang.manage">Quản lý ngôn ngữ</div>
            <label class="btn btn-primary btn-sm" style="cursor:pointer;display:flex;align-items:center;gap:6px">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
              <span data-i18n="lang.upload">Upload ngôn ngữ</span>
              <input type="file" id="langFileInput" accept=".json" style="display:none">
            </label>
          </div>
          <div id="langListContent">
            <div style="text-align:center;padding:24px;color:var(--text-muted)" data-i18n="msg.loading">Đang tải...</div>
          </div>
          <div style="margin-top:14px;font-size:12px;color:var(--text-muted)">
            <svg class="inline-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 15h6"/><path d="M9 18h6"/></svg>
            <a href="assets/lang/vi.json" download="lang-template.json" style="color:var(--primary);text-decoration:none" data-i18n="lang.template">Tải file mẫu</a>
            <span data-i18n-html="lang.template_hint">&nbsp;— chỉnh sửa các giá trị (không đổi key), giữ nguyên <code>_meta</code>, rồi upload.</span>
          </div>
        </div>
      </div>

      <!-- ── Hệ thống (system info, version, update, brand rules, danger zone) ─ -->
      <div class="page" id="page-system">
        <div class="page-header">
          <h1><span data-i18n="page.system.title">Hệ thống</span> <span id="currentVersionBadge" style="font-size:13px;font-weight:500;color:var(--text-muted);vertical-align:middle"></span></h1>
          <p data-i18n="page.system.sub">Thông tin server, database, cập nhật và các thao tác quản trị nâng cao.</p>
        </div>

        <!-- System info -->
        <div class="card mb-4">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
            <div class="card-title" style="margin-bottom:0" data-i18n="system.info.title">Thông tin hệ thống</div>
            <button id="btnRefreshSysInfo" class="btn btn-secondary btn-sm">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 0 1-15.5 6.2"/><path d="M3 12A9 9 0 0 1 18.5 5.8"/><path d="M18 2v5h-5"/><path d="M6 22v-5h5"/></svg>
              <span data-i18n="btn.refresh">Làm mới</span>
            </button>
          </div>
          <div id="sysInfoContent">
            <div style="text-align:center;padding:32px;color:var(--text-muted)" data-i18n="msg.loading">Đang tải...</div>
          </div>
        </div>

        <!-- Data stats -->
        <div class="card mb-4">
          <div class="card-title" data-i18n="system.data_stats.title">Thống kê dữ liệu</div>
          <div id="dataStatsContent">
            <div style="text-align:center;padding:24px;color:var(--text-muted)" data-i18n="msg.loading">Đang tải...</div>
          </div>
        </div>

        <!-- Auto update -->
        <div class="card mb-4">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
            <div class="card-title" style="margin-bottom:0" data-i18n="system.update.title">Cập nhật tự động</div>
            <button id="btnCheckUpdateNow" class="btn btn-secondary btn-sm">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 0 1-15.5 6.2"/><path d="M3 12A9 9 0 0 1 18.5 5.8"/><path d="M18 2v5h-5"/><path d="M6 22v-5h5"/></svg>
              <span data-i18n="update.check_now">Kiểm tra ngay</span>
            </button>
          </div>

          <div style="margin-bottom:16px">
            <label style="font-size:12px;color:var(--text-muted);display:block;margin-bottom:6px">
              <span data-i18n="update.manifest_url">URL Manifest cập nhật</span>
              <span style="font-size:11px;opacity:.7" data-i18n="update.manifest_url_hint">— file JSON chứa thông tin phiên bản mới nhất</span>
            </label>
            <div style="display:flex;gap:8px">
              <input type="url" id="inputManifestUrl" class="form-control"
                     value="https://raw.githubusercontent.com/namct2610/ecom-dashboard/main/manifest.json"
                     readonly
                     style="flex:1;font-size:13px">
            </div>
            <div style="font-size:11px;color:var(--text-muted);margin-top:5px" data-i18n="update.production_manifest_note">
              Production chỉ sử dụng duy nhất manifest này. Không cần nhập URL theo tag phiên bản.
            </div>
          </div>

          <div id="updateStatusPanel">
            <div style="text-align:center;padding:20px;color:var(--text-muted);font-size:13px" data-i18n="msg.loading">Đang tải...</div>
          </div>
        </div><!-- /auto update -->

        <!-- SKU brand settings -->
        <div class="card mb-4" id="brandSettingsCard">
          <div class="reconcile-settings-head">
            <div>
              <div class="card-title" style="margin-bottom:4px" data-i18n="brand.settings.title">Quy ước SKU sang Thương hiệu</div>
              <div class="card-subtitle" data-i18n="brand.settings.sub">Thiết lập tên thương hiệu theo đúng 3 ký tự đầu trong mã SKU để dùng trong phần phân tích.</div>
            </div>
            <div class="reconcile-settings-actions">
              <button id="btnReloadBrandSettings" class="btn btn-secondary btn-sm" data-i18n="btn.reload">Tải lại</button>
              <button id="btnSaveBrandSettings" class="btn btn-primary btn-sm" data-i18n="brand.btn.save">Lưu thương hiệu</button>
            </div>
          </div>

          <div class="reconcile-settings-banner">
            <strong data-i18n="brand.banner.title">Nhận diện thương hiệu:</strong>
            <span data-i18n="brand.banner.desc">hệ thống lấy 3 ký tự đầu của SKU sau khi chuẩn hóa chữ hoa.</span>
            <span data-i18n="brand.banner.example">Ví dụ SKU `MON055GH04VAN` sẽ thuộc mã thương hiệu `MON`.</span>
          </div>

          <div class="reconcile-settings-summary" id="brandSettingsSummary">
            <span class="reconcile-settings-chip" data-i18n="brand.loading">Đang tải quy ước thương hiệu...</span>
          </div>

          <div class="brand-settings-toolbar">
            <button id="btnAddBrandRuleRow" class="btn btn-primary btn-sm" data-i18n="brand.btn.add_row">Thêm dòng</button>
          </div>

          <div class="table-wrapper">
            <table class="reconcile-settings-table brand-settings-table">
              <thead>
                <tr>
                  <th data-i18n="brand.th.sku_code">Mã SKU 3 ký tự</th>
                  <th data-i18n="brand.th.brand_name">Tên thương hiệu</th>
                  <th data-i18n="th.actions">Thao tác</th>
                </tr>
              </thead>
              <tbody id="brandRuleTableBody">
                <tr><td colspan="3" class="reconcile-settings-empty" data-i18n="msg.loading">Đang tải dữ liệu...</td></tr>
              </tbody>
            </table>
          </div>

          <div id="brandSettingsResult" class="reconcile-settings-result" aria-live="polite"></div>
        </div>

        <!-- Danger zone -->
        <div class="card" style="border:2px solid #fecaca">
          <div class="card-title" style="color:#dc2626;display:flex;align-items:center;gap:8px">
            <svg class="inline-icon icon-status-warning" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>
            <span data-i18n="danger.title">Vùng nguy hiểm — Reset Database</span>
          </div>
          <p style="color:var(--text-muted);font-size:13px;margin-bottom:20px" data-i18n="danger.sub">
            Các thao tác dưới đây không thể hoàn tác. Hãy chắc chắn trước khi thực hiện.
          </p>

          <div style="display:flex;flex-direction:column;gap:12px">

            <!-- Reset orders -->
            <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px;background:#fef2f2;border-radius:10px;gap:16px;flex-wrap:wrap">
              <div>
                <div style="font-weight:600;font-size:14px;color:#1e293b" data-i18n="danger.orders.title">Xóa dữ liệu đơn hàng</div>
                <div style="font-size:12px;color:var(--text-muted);margin-top:2px" data-i18n="danger.orders.desc">Xóa toàn bộ orders, traffic, upload_history, import_errors</div>
              </div>
              <button class="btn btn-sm" style="background:#ef4444;color:#fff;border:none;white-space:nowrap"
                      onclick="confirmReset('reset_orders',t('danger.orders.confirm'),t('danger.orders.prompt'),'DELETE ORDERS')"
                      data-i18n="danger.orders.button">
                Xóa dữ liệu đơn hàng
              </button>
            </div>

            <!-- Reset API connections -->
            <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px;background:#fef2f2;border-radius:10px;gap:16px;flex-wrap:wrap">
              <div>
                <div style="font-weight:600;font-size:14px;color:#1e293b" data-i18n="danger.api.title">Xóa kết nối API</div>
                <div style="font-size:12px;color:var(--text-muted);margin-top:2px" data-i18n="danger.api.desc">Xóa TikTok & Lazada connections, App Key/Secret đã lưu</div>
              </div>
              <button class="btn btn-sm" style="background:#ef4444;color:#fff;border:none;white-space:nowrap"
                      onclick="confirmReset('reset_api_connections',t('danger.api.confirm'),t('danger.api.prompt'),'DELETE API')"
                      data-i18n="danger.api.button">
                Xóa kết nối API
              </button>
            </div>

            <!-- Reset logs -->
            <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px;background:#fffbeb;border-radius:10px;gap:16px;flex-wrap:wrap">
              <div>
                <div style="font-weight:600;font-size:14px;color:#1e293b" data-i18n="danger.logs.title">Xóa nhật ký hệ thống</div>
                <div style="font-size:12px;color:var(--text-muted);margin-top:2px" data-i18n="danger.logs.desc">Xóa toàn bộ app_logs (không ảnh hưởng đến dữ liệu)</div>
              </div>
              <button class="btn btn-sm" style="background:#f59e0b;color:#fff;border:none;white-space:nowrap"
                      onclick="confirmReset('reset_logs',t('danger.logs.confirm'),t('danger.logs.prompt'),'DELETE LOGS')"
                      data-i18n="danger.logs.button">
                Xóa nhật ký
              </button>
            </div>

            <!-- Full reset -->
            <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px;background:#fef2f2;border:2px dashed #fca5a5;border-radius:10px;gap:16px;flex-wrap:wrap">
              <div>
                <div style="font-weight:700;font-size:14px;color:#dc2626;display:flex;align-items:center;gap:6px">
                  <svg class="inline-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 15H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>
                  <span data-i18n="danger.all.title">Reset TOÀN BỘ database</span>
                </div>
                <div style="font-size:12px;color:var(--text-muted);margin-top:2px" data-i18n="danger.all.desc">Xóa tất cả: đơn hàng, traffic, API keys, logs, cài đặt</div>
              </div>
              <button class="btn btn-sm" style="background:#7f1d1d;color:#fff;border:none;white-space:nowrap"
                      onclick="confirmReset('reset_all',t('danger.all.confirm'),t('danger.all.prompt'),'RESET ALL')">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 15H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>
                <span data-i18n="danger.all.button">Reset toàn bộ</span>
              </button>
            </div>

          </div><!-- reset actions -->

          <div id="resetResult" style="margin-top:16px"></div>
        </div><!-- danger zone -->

      </div><!-- /#page-system -->

    </div><!-- /#content -->
  </div><!-- /#main -->
</div><!-- /#app -->

<div class="customer-detail-drawer" id="customerDetailDrawer" aria-hidden="true">
  <div class="customer-detail-backdrop" data-customer-close></div>
  <aside class="customer-detail-panel">
    <div class="customer-detail-header">
      <div class="customer-detail-topline">
        <div>
          <div class="customer-detail-eyebrow" data-i18n="customer.detail.eyebrow">Hồ sơ khách hàng</div>
          <div class="customer-detail-title" id="customerDetailTitle">—</div>
          <div class="customer-detail-subtitle" id="customerDetailSubtitle">—</div>
        </div>
        <button class="customer-close-btn" id="btnCloseCustomerDetail" type="button" aria-label="Close">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
    </div>
    <div class="customer-detail-body" id="customerDetailBody">
      <div class="customer-detail-loading" data-i18n="customer.detail.loading">Đang tải thông tin khách hàng...</div>
    </div>
  </aside>
</div>

<div class="password-modal profile-modal" id="profileModal" aria-hidden="true">
  <div class="password-modal-backdrop" data-profile-close></div>
  <div class="password-modal-panel" role="dialog" aria-modal="true" aria-labelledby="profileModalTitle">
    <div class="password-modal-head">
      <div>
        <div class="password-modal-eyebrow" data-i18n="user.menu.account">Tài khoản</div>
        <h3 class="password-modal-title" id="profileModalTitle" data-i18n="account.profile.title">Hồ sơ tài khoản</h3>
        <p class="password-modal-sub" data-i18n="account.profile.sub">Bạn có thể tự cập nhật tên hiển thị và ảnh đại diện dùng trong dashboard.</p>
      </div>
      <button class="password-close-btn" id="btnCloseProfileModal" type="button" aria-label="Close">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>

    <form class="password-form" id="profileForm" autocomplete="off">
      <div class="profile-avatar-section">
        <div class="profile-avatar-preview" id="profileAvatarPreview"><?= htmlspecialchars($initials) ?></div>
        <div class="profile-avatar-actions">
          <input id="profileAvatarFile" type="file" accept="image/png,image/jpeg,image/webp" hidden>
          <button class="btn btn-secondary" id="btnChooseAvatar" type="button" data-i18n="account.profile.choose_avatar">Chọn avatar</button>
          <button class="btn btn-secondary" id="btnRemoveAvatar" type="button" data-i18n="account.profile.remove_avatar">Xóa avatar</button>
          <div class="password-note" data-i18n="account.profile.avatar_hint">Hỗ trợ JPG, PNG, WEBP tối đa 2MB.</div>
        </div>
      </div>

      <div class="password-field">
        <label for="profileFullName" data-i18n="account.profile.full_name">Tên hiển thị</label>
        <input id="profileFullName" type="text" maxlength="255" autocomplete="name">
      </div>

      <div class="password-field">
        <label for="profileUsername" data-i18n="account.profile.username">Tên đăng nhập</label>
        <input id="profileUsername" type="text" disabled>
      </div>

      <div class="password-form-error" id="profileFormError"></div>

      <div class="password-actions">
        <button class="btn btn-secondary" id="btnCancelProfileModal" type="button" data-i18n="account.password.cancel">Đóng</button>
        <button class="btn btn-primary" id="btnSubmitProfileModal" type="submit" data-i18n="account.profile.submit">Lưu hồ sơ</button>
      </div>
    </form>
  </div>
</div>

<div class="password-modal" id="passwordModal" aria-hidden="true">
  <div class="password-modal-backdrop" data-password-close></div>
  <div class="password-modal-panel" role="dialog" aria-modal="true" aria-labelledby="passwordModalTitle">
    <div class="password-modal-head">
      <div>
        <div class="password-modal-eyebrow" data-i18n="user.menu.account">Tài khoản</div>
        <h3 class="password-modal-title" id="passwordModalTitle" data-i18n="account.password.title">Đổi mật khẩu</h3>
        <p class="password-modal-sub" data-i18n="account.password.sub">Mật khẩu mới sẽ được áp dụng ngay cho lần đăng nhập tiếp theo.</p>
      </div>
      <button class="password-close-btn" id="btnClosePasswordModal" type="button" aria-label="Close">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>

    <form class="password-form" id="changePasswordForm" autocomplete="off">
      <div class="password-force-alert" id="passwordForceAlert" hidden>
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
        </svg>
        <div>
          <strong data-i18n="account.password.force.title">Bạn cần đổi mật khẩu trước khi tiếp tục</strong>
          <span data-i18n="account.password.force.sub">Đây là mật khẩu tạm do admin thiết lập. Mật khẩu mới phải đạt tối thiểu mức Trung bình.</span>
        </div>
      </div>

      <div class="password-field">
        <label for="currentPassword" data-i18n="account.password.current">Mật khẩu hiện tại</label>
        <input id="currentPassword" type="password" autocomplete="current-password" required>
      </div>

      <div class="password-field">
        <label for="newPassword" data-i18n="account.password.new">Mật khẩu mới</label>
        <input id="newPassword" type="password" autocomplete="new-password" required>
        <div class="password-strength is-empty" id="changePasswordStrength">
          <div class="password-strength-bar"><span class="password-strength-fill"></span></div>
          <div class="password-strength-meta">
            <span class="password-strength-value" data-i18n="password.strength.empty">Chưa nhập mật khẩu</span>
            <span class="password-strength-note" data-i18n="password.strength.minimum">Yêu cầu tối thiểu mức Trung bình</span>
          </div>
        </div>
        <div class="password-strength-rules">
          <span class="password-strength-rule" data-password-rule="length" data-i18n="password.rule.length">Từ 8 ký tự trở lên</span>
          <span class="password-strength-rule" data-password-rule="variety" data-i18n="password.rule.variety">Ít nhất 2 nhóm ký tự: chữ, số hoặc ký tự đặc biệt</span>
        </div>
      </div>

      <div class="password-field">
        <label for="confirmPassword" data-i18n="account.password.confirm">Xác nhận mật khẩu mới</label>
        <input id="confirmPassword" type="password" autocomplete="new-password" required>
      </div>

      <div class="password-note" data-i18n="account.password.hint">Mật khẩu mới phải đạt tối thiểu mức Trung bình: từ 8 ký tự và có ít nhất 2 nhóm ký tự.</div>
      <div class="password-form-error" id="changePasswordError"></div>

      <div class="password-actions">
        <button class="btn btn-secondary" id="btnCancelPasswordModal" type="button" data-i18n="account.password.cancel">Đóng</button>
        <button class="btn btn-primary" id="btnSubmitPasswordModal" type="submit" data-i18n="account.password.submit">Cập nhật mật khẩu</button>
      </div>
    </form>
  </div>
</div>

<!-- Scripts -->
<script src="assets/js/charts.js"></script>
<script src="assets/js/upload.js"></script>
<script src="assets/js/app.js"></script>
<script>
  // Expose Upload globally for inline onclick handlers in upload.js
  window.Upload = Upload;

  // Init upload UI when its nav item is clicked
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('[data-page="upload"]')?.addEventListener('click', () => {
      setTimeout(() => Upload.init(), 80);
    });

    // Show toast after OAuth redirect
    const usp = new URLSearchParams(location.search);
    if (usp.has('tiktok_connected')) {
      const n = usp.get('tiktok_connected');
      toast(tFormat('connect.oauth.tiktok_success', { n }), 'success');
      history.replaceState({}, '', location.pathname + '#admin');
      setTimeout(() => window.openAdminTab?.('api'), 300);
    } else if (usp.has('tiktok_error')) {
      toast(`${t('connect.oauth.tiktok_error')} ${usp.get('tiktok_error')}`, 'error');
      history.replaceState({}, '', location.pathname);
    } else if (usp.has('shopee_connected')) {
      toast(t('connect.oauth.shopee_success'), 'success');
      history.replaceState({}, '', location.pathname + '#admin');
      setTimeout(() => {
        window.openAdminTab?.('api');
        switchConnectTab('shopee');
      }, 300);
    } else if (usp.has('shopee_error')) {
      toast(`${t('connect.oauth.shopee_error')} ${usp.get('shopee_error')}`, 'error');
      history.replaceState({}, '', location.pathname);
    } else if (usp.has('lazada_connected')) {
      toast(t('connect.oauth.lazada_success'), 'success');
      history.replaceState({}, '', location.pathname + '#admin');
      setTimeout(() => {
        window.openAdminTab?.('api');
        switchConnectTab('lazada');
      }, 300);
    } else if (usp.has('lazada_error')) {
      toast(`${t('connect.oauth.lazada_error')} ${usp.get('lazada_error')}`, 'error');
      history.replaceState({}, '', location.pathname);
    }
  });
</script>
</body>
</html>
