#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$ROOT_DIR"

BRANCH="$(git rev-parse --abbrev-ref HEAD)"
REMOTE="${GIT_REMOTE:-origin}"
MESSAGE="${1:-Update production release}"

if [[ "$BRANCH" == "HEAD" ]]; then
  echo "Dang o detached HEAD, khong the push an toan." >&2
  exit 1
fi

if git status --short | grep -E '(^|[[:space:]])(config\.php|config\.local\.php|\.env|\.env\.|uploads/|.*\.sql$)' >/dev/null; then
  echo "Phat hien file nhay cam hoac du lieu local trong working tree. Kiem tra git status truoc khi push." >&2
  git status --short
  exit 1
fi

if git diff --quiet && git diff --cached --quiet; then
  echo "Khong co thay doi moi de commit. Thu push cac commit da co..."
else
  echo "Cac thay doi se duoc commit:"
  git status --short
  git add -A
  git commit -m "$MESSAGE"
fi

git push "$REMOTE" "$BRANCH"

echo "Da push len $REMOTE/$BRANCH"
