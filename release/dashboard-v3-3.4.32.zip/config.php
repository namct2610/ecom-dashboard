<?php

declare(strict_types=1);

return [
    'app' => [
        'name'             => 'Business Dashboard',
        'timezone'         => 'Asia/Ho_Chi_Minh',
        'base_path'        => __DIR__,
        'upload_path'      => __DIR__ . '/uploads',
        'max_upload_size'  => 50 * 1024 * 1024, // 50 MB
        'allowed_platforms'=> ['shopee', 'lazada', 'tiktokshop'],
    ],
    'db' => [
        'host'     => getenv('DB_HOST') ?: '127.0.0.1',
        'port'     => getenv('DB_PORT') ?: '3306',
        'database' => getenv('DB_NAME') ?: 'dashboard_v3',
        'username' => getenv('DB_USER') ?: 'root',
        'password' => getenv('DB_PASS') ?: '',
        'charset'  => 'utf8mb4',
    ],
    // Set 'enabled' => true via config.local.php to require login.
    // User accounts are managed in the database (Trang Người dùng).
    'auth' => [
        'enabled' => false,
    ],
];
