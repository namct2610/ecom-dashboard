#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  publish.sh — Push code + tạo GitHub Release tự động
#
#  Cách dùng:
#    bash others/publish.sh
#
#  GITHUB_TOKEN được tải theo thứ tự ưu tiên:
#    1. Đã export sẵn trong shell:  export GITHUB_TOKEN=...
#    2. File ~/.dashboard_token     (chỉ chứa token, không có gì khác)
#
#  Tạo file token lần đầu:
#    echo "github_pat_xxxx" > ~/.dashboard_token && chmod 600 ~/.dashboard_token
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# ── Load token ────────────────────────────────────────────────────────────────
TOKEN_FILE="$HOME/.dashboard_token"

if [[ -z "${GITHUB_TOKEN:-}" ]]; then
  if [[ -f "$TOKEN_FILE" ]]; then
    GITHUB_TOKEN=$(tr -d '[:space:]' < "$TOKEN_FILE")
    export GITHUB_TOKEN
    echo "🔑 Loaded token from $TOKEN_FILE"
  else
    echo "❌ Cần GITHUB_TOKEN."
    echo ""
    echo "   Lưu token vĩnh viễn (chỉ cần làm 1 lần):"
    echo "   echo \"github_pat_xxxx\" > ~/.dashboard_token && chmod 600 ~/.dashboard_token"
    echo ""
    echo "   Hoặc export tạm thời:"
    echo "   export GITHUB_TOKEN=github_pat_xxxx && bash others/publish.sh"
    exit 1
  fi
fi

VERSION=$(cat "$PROJECT_DIR/version.txt" | tr -d '[:space:]')

echo "🚀 Publishing v${VERSION}..."
echo ""

# ── Git push ──────────────────────────────────────────────────────────────────
echo "⬆️  Pushing to GitHub..."
git -C "$PROJECT_DIR" push origin main

echo ""

# ── GitHub Release ────────────────────────────────────────────────────────────
bash "$SCRIPT_DIR/release.sh"
