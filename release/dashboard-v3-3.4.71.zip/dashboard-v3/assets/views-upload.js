/* ============================================================
   View: Upload (Tải dữ liệu) — Excel order/traffic import
   Reuses /api/upload.php and /api/upload-history.php
   Drag-drop + click-to-pick; multi-file; per-file result rows.
   ============================================================ */
(function () {
  const local = {
    uploading: false,
    queue: [],       // [{ name, size, status:'pending'|'uploading'|'done'|'error', result }]
    msg: null,
    csrf: "",
    catalog: null,          // dữ liệu thô đang có, để biết xuất được gì
    exportPick: { platform: "", file_type: "", from: "", to: "" },
    coverage: null,   // { loading, error, months, types }
  };

  // PHP emits its "POST Content-Length exceeds the limit" warning at request
  // startup, before any of our code can set display_errors — so the body is that
  // HTML followed by our JSON. Parsing strictly turns a clear server message
  // into "Unexpected token '<'", so pull the JSON object out of whatever came
  // back and fall back to trimmed text.
  async function readJson(resp) {
    const text = await resp.text();
    try { return JSON.parse(text); } catch (_) { /* fall through */ }
    const i = text.indexOf("{"), j = text.lastIndexOf("}");
    if (i >= 0 && j > i) {
      try { return JSON.parse(text.slice(i, j + 1)); } catch (_) { /* fall through */ }
    }
    const plain = text.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
    return { success: false, error: plain.slice(0, 300) || ("HTTP " + resp.status) };
  }

  async function fetchCsrf() {
    if (local.csrf) return local.csrf;
    const r = await fetch("api/auth.php", { credentials: "same-origin" });
    local.csrf = (await r.json()).csrf || "";
    return local.csrf;
  }

  function fmtBytes(b) {
    if (!b) return "—";
    if (b < 1024) return b + " B";
    if (b < 1024 * 1024) return (b / 1024).toFixed(1) + " KB";
    return (b / 1024 / 1024).toFixed(1) + " MB";
  }
  function fmtDT(s) {
    if (!s) return "—";
    const d = new Date(s.replace(" ", "T"));
    if (isNaN(d)) return s;
    return d.toLocaleDateString("vi-VN") + " " + d.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" });
  }


  function showMsg(kind, text) {
    local.msg = { kind, text };
    window.App.rerender();
    setTimeout(() => { local.msg = null; window.App.rerender(); }, 5000);
  }

  const flashMsg = () => window.UI.flashMsg(local.msg);

  // 3 loại file, không mặc định về "Đơn hàng" nữa: báo cáo tài chính bị gán
  // nhầm nhãn thì người dùng tưởng import sai.
  function typeLabel(dataType) {
    if (dataType === "traffic") return t("upload.type.traffic");
    if (dataType === "settlement") return t("upload.type.settlement");
    return t("upload.type.orders");
  }

  function platPill(p) {
    if (!p) return "—";
    const key = p === "tiktokshop" ? "tiktok" : p;
    const labels = { shopee: "Shopee", lazada: "Lazada", tiktok: "TikTok Shop", tiktokshop: "TikTok Shop" };
    return `<span class="pchip"><span class="pdot" style="background:var(--${key})"></span>${labels[p] || p}</span>`;
  }

  function statusPill(s) {
    if (s === "completed") return `<span class="status-pill st-done">${t("status.completed")}</span>`;
    if (s === "failed")    return `<span class="status-pill st-cancel">${t("status.failed")}</span>`;
    if (s === "processing") return `<span class="status-pill st-ship">${t("status.processing")}</span>`;
    return `<span class="status-pill">${s || "—"}</span>`;
  }

  function dropZone() {
    return `
      <div id="dropZone" style="border:2px dashed var(--border-strong);border-radius:var(--r-card);padding:36px 22px;text-align:center;transition:background .15s, border-color .15s;cursor:pointer">
        <div style="margin:0 auto 12px;width:54px;height:54px;border-radius:14px;background:color-mix(in oklch, var(--brand) 12%, transparent);color:var(--brand);display:grid;place-items:center">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:24px;height:24px"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M17 8l-5-5-5 5M12 3v12"/></svg>
        </div>
        <div style="font-weight:800;font-size:15px">${t("upload.dropzone.title")}</div>
        <div style="font-size:12.5px;color:var(--ink-3);font-weight:600;margin-top:6px">${t("upload.dropzone.hint1")}</div>
        <div style="font-size:11.5px;color:var(--ink-3);font-weight:600;margin-top:4px">${t("upload.dropzone.hint2")}</div>
        <button class="ctrl-btn on" id="btnPickFile" style="background:var(--brand);border-color:var(--brand);color:#fff;margin-top:16px">${t("upload.pick")}</button>
        <input id="fileInput" type="file" multiple accept=".xlsx,.xls" style="display:none" />
      </div>`;
  }

  function queueItem(q, idx) {
    let badge;
    if (q.status === "pending") badge = `<span class="tag">${t("upload.queue.pending")}</span>`;
    else if (q.status === "uploading") badge = `<span class="tag" style="color:var(--lazada);border-color:color-mix(in oklch, var(--lazada) 30%, transparent)">${t("upload.queue.uploading")}</span>`;
    else if (q.status === "done") {
      const r = q.result || {};
      const platLabel = (r.platform === "tiktokshop" ? "tiktok" : r.platform);
      badge = `<span class="tag" style="color:var(--pos);border-color:color-mix(in oklch, var(--pos) 30%, transparent)">${tf("upload.queue.done", { n: r.imported || 0 })}</span>
               <span class="tag mono">${platLabel || "?"}</span>
               <span class="tag">${typeLabel(r.data_type)}</span>`;
    } else {
      badge = `<span class="tag" style="color:var(--neg);border-color:color-mix(in oklch, var(--neg) 30%, transparent)">✗ ${(q.result && q.result.error) || t("upload.queue.error_default")}</span>`;
    }
    return `
      <div style="display:flex;align-items:center;gap:12px;padding:10px 14px;border:1px solid var(--border);border-radius:var(--r-ctrl);background:var(--surface-2);margin-top:8px">
        <div style="width:32px;height:32px;border-radius:8px;background:var(--surface-3);color:var(--ink-2);display:grid;place-items:center">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;height:16px"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>
        </div>
        <div style="flex:1;min-width:0">
          <div style="font-weight:700;font-size:13.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${q.name}</div>
          <div style="font-size:11.5px;color:var(--ink-3);font-weight:600">${fmtBytes(q.size)}</div>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end">${badge}</div>
      </div>`;
  }

  function uploadCard() {
    const totalDone = local.queue.filter((q) => q.status === "done").length;
    const totalErr  = local.queue.filter((q) => q.status === "error").length;
    return `
      <div class="card">
        <div class="card-head">
          <div>
            <div class="card-title">${t("upload.card.title")}</div>
            
          </div>
          ${local.queue.length ? `<div style="font-size:12.5px;color:var(--ink-3);font-weight:700">${totalErr ? tf("upload.queue.summary_with_errors", { done: totalDone, total: local.queue.length, err: totalErr }) : tf("upload.queue.summary", { done: totalDone, total: local.queue.length })}</div>` : ""}
        </div>
        <div class="card-pad">
          ${dropZone()}
          ${local.queue.length ? `<div style="margin-top:6px">${local.queue.map(queueItem).join("")}</div>` : ""}
          ${local.queue.length && !local.uploading ? `<div style="margin-top:14px;display:flex;justify-content:flex-end"><button class="ctrl-btn" id="btnClearQueue">${t("upload.clear_queue")}</button></div>` : ""}
        </div>
      </div>`;
  }


  const TYPE_ORDER = ["orders", "settlement", "traffic"];

  function exportCard() {
    const cat = local.catalog;
    if (cat === null) {
      return `<div class="card section-gap"><div class="card-pad" style="color:var(--ink-3);font-weight:600">${t("common.loading")}</div></div>`;
    }
    if (!cat.length) {
      return `
        <div class="card section-gap">
          <div class="card-head"><div><div class="card-title">${t("export.title")}</div></div></div>
          <div class="card-pad"><div class="note" style="margin:0"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>${t("export.empty")}</div></div>
        </div>`;
    }

    const p = local.exportPick;
    const sorted = cat.slice().sort((a, b) =>
      TYPE_ORDER.indexOf(a.file_type) - TYPE_ORDER.indexOf(b.file_type) || a.platform.localeCompare(b.platform));
    const rows = sorted.map((c) => {
      const on = p.platform === c.platform && p.file_type === c.file_type;
      return `<tr data-pick="${c.platform}|${c.file_type}" style="cursor:pointer${on ? ";background:var(--surface-2)" : ""}">
        <td><input type="radio" name="expPick" ${on ? "checked" : ""} style="accent-color:var(--brand)"></td>
        <td>${platPill(c.platform)}</td>
        <td>${typeLabel(c.file_type)}</td>
        <td class="num tnum">${(+c.rows || 0).toLocaleString("vi-VN")}</td>
        <td class="mono" style="font-size:12px;color:var(--ink-3)">${c.date_from || "?"} → ${c.date_to || "?"}</td>
        <td class="num tnum" style="font-size:12px;color:${c.undated ? "var(--neg)" : "var(--ink-3)"}">${c.undated ? (+c.undated).toLocaleString("vi-VN") : "—"}</td>
      </tr>`;
    }).join("");

    const ready = p.platform && p.file_type && p.from && p.to;
    return `
      <div class="card section-gap">
        <div class="card-head"><div><div class="card-title">${t("export.title")}</div></div></div>
        <div class="card-pad" style="padding:6px;overflow-x:auto">
          <table class="tbl"><thead><tr>
            <th style="width:34px"></th><th>${t("th.platform")}</th><th>${t("export.col.type")}</th>
            <th class="num">${t("export.col.rows")}</th><th>${t("export.col.range")}</th>
            <th class="num">${t("export.col.undated")}</th>
          </tr></thead><tbody>${rows}</tbody></table>
        </div>
        <div class="card-pad" style="display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;border-top:1px solid var(--border)">
          <label style="display:flex;flex-direction:column;gap:5px;font-size:12px;font-weight:700;color:var(--ink-2)">
            ${t("export.from")}
            <input type="date" id="expFrom" value="${p.from}" style="padding:8px 10px;border:1px solid var(--border);border-radius:var(--r-ctrl);background:var(--surface-2);color:var(--ink);font-family:inherit;font-size:13px">
          </label>
          <label style="display:flex;flex-direction:column;gap:5px;font-size:12px;font-weight:700;color:var(--ink-2)">
            ${t("export.to")}
            <input type="date" id="expTo" value="${p.to}" style="padding:8px 10px;border:1px solid var(--border);border-radius:var(--r-ctrl);background:var(--surface-2);color:var(--ink);font-family:inherit;font-size:13px">
          </label>
          <button class="ctrl-btn on" id="expBtn" ${ready ? "" : "disabled"} style="background:var(--brand);border-color:var(--brand);color:#fff${ready ? "" : ";opacity:.5;cursor:not-allowed"}">
            ${t("export.download")}
          </button>
          <div style="flex:1 1 260px;min-width:0;font-size:12px;color:var(--ink-3);font-weight:600;line-height:1.5">${t("export.note")}</div>
        </div>
      </div>`;
  }

  /* ── data coverage grid (thay cho lịch sử upload) ────────── */

  const COV_TYPES = [
    { key: "traffic", label: "upload.cov.traffic" },
    { key: "orders",  label: "upload.cov.orders" },
    { key: "finance", label: "upload.cov.finance" },
    { key: "ads",     label: "upload.cov.ads" },
  ];

  async function fetchCoverage() {
    local.coverage = { loading: true };
    window.App.rerender();
    try {
      const r = await fetch("api/data-coverage.php", { credentials: "same-origin" });
      const j = await r.json();
      if (!r.ok || !j.success) throw new Error(j.error || "HTTP " + r.status);
      local.coverage = { months: j.months || [], types: j.types || [] };
    } catch (e) {
      local.coverage = { error: e.message || String(e) };
    }
    window.App.rerender();
  }

  function covCell(cell, typeKey) {
    const st = (cell && cell.state) || "none";
    // Numbers stay on the cell: a yellow month is only actionable if you can see
    // it is 10/31 days rather than 30/31.
    const detail = st === "unsupported" ? t("upload.cov.unsupported")
      : cell.unit === "orders" ? tf("upload.cov.detail_orders", { have: fmtInt(cell.have), total: fmtInt(cell.expected) })
      : tf("upload.cov.detail_days", { have: fmtInt(cell.have), total: fmtInt(cell.expected) });
    return `<td class="cov-cell"><span class="cov cov-${st}" title="${t("upload.cov." + typeKey)}: ${detail}">
      <span class="cov-dot"></span><span class="cov-txt">${st === "unsupported" ? "—" : detail}</span>
    </span></td>`;
  }

  const fmtInt = (n) => (+n || 0).toLocaleString("vi-VN");

  function monthLabel(ym) {
    const [y, m] = ym.split("-");
    return tf("period.month_n", { n: +m, y });
  }

  function coverageTable() {
    const c = local.coverage || {};
    if (c.loading) return `<div style="padding:24px;text-align:center;color:var(--ink-3);font-weight:600">${t("common.loading")}</div>`;
    if (c.error) return `<div style="padding:24px;text-align:center;color:var(--neg);font-weight:700">${t("common.error")}: ${window.UI.esc(c.error)}</div>`;
    if (!c.months || !c.months.length) return `<div style="padding:32px;text-align:center;color:var(--ink-3);font-weight:600">${t("upload.cov.empty")}</div>`;

    const head = COV_TYPES.map((ty) => `<th>${t(ty.label)}</th>`).join("");
    const rows = c.months.map((m) => `<tr>
      <td style="font-weight:700;white-space:nowrap">${monthLabel(m.ym)}</td>
      ${COV_TYPES.map((ty) => covCell(m.cells[ty.key], ty.key)).join("")}
    </tr>`).join("");

    return `<div class="card-pad" style="padding:6px 6px 10px;overflow-x:auto">
      <table class="tbl"><thead><tr><th>${t("upload.cov.month")}</th>${head}</tr></thead><tbody>${rows}</tbody></table>
      <div class="note" style="margin-top:12px">${window.UI.ICON.info} ${t("upload.cov.note")}</div>
    </div>`;
  }

  function render() {
    return `
      ${flashMsg()}
      ${uploadCard()}
      ${exportCard()}
      <div class="card section-gap">
        <div class="card-head">
          <div><div class="card-title">${t("upload.cov.title")}</div></div>
          <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
            <span class="cov-legend"><span class="cov cov-full"><span class="cov-dot"></span></span>${t("upload.cov.legend_full")}</span>
            <span class="cov-legend"><span class="cov cov-partial"><span class="cov-dot"></span></span>${t("upload.cov.legend_partial")}</span>
            <span class="cov-legend"><span class="cov cov-none"><span class="cov-dot"></span></span>${t("upload.cov.legend_none")}</span>
            <button class="ctrl-btn" id="btnReloadCov">${t("common.reload")}</button>
          </div>
        </div>
        ${coverageTable()}
      </div>`;
  }

  /* ── interactions ────────────────────────────────────────── */

  function addFiles(fileList) {
    if (local.uploading) return;
    const accepted = [];
    for (const f of fileList) {
      const ext = (f.name || "").toLowerCase().split(".").pop();
      if (!["xlsx", "xls"].includes(ext)) continue;
      if (f.size > 50 * 1024 * 1024) {
        showMsg("err", tf("upload.too_big", { name: f.name }));
        continue;
      }
      accepted.push({ name: f.name, size: f.size, raw: f, status: "pending" });
    }
    if (!accepted.length) { showMsg("err", t("upload.invalid")); return; }
    local.queue = local.queue.concat(accepted);
    window.App.rerender();
    runQueue();
  }

  async function runQueue() {
    if (local.uploading) return;
    const pending = local.queue.filter((q) => q.status === "pending");
    if (!pending.length) return;
    local.uploading = true;
    try {
      // api/upload.php enforces CSRF; fetch the token once per upload run.
      const csrf = await fetchCsrf();

      for (const item of pending) {
        item.status = "uploading";
        window.App.rerender();

        const fd = new FormData();
        fd.append("files[]", item.raw);
        try {
          const r = await fetch("api/upload.php", { method: "POST", credentials: "same-origin", headers: { "X-CSRF-Token": csrf }, body: fd });
          const j = await readJson(r);
          // upload.php returns { success, message, results: [{file, success, ...}] }
          const file = j.results && j.results[0] ? j.results[0] : { success: false, error: t("common.no_results") };
          if (file.success) {
            item.status = "done";
            item.result = file;
          } else {
            item.status = "error";
            item.result = { error: file.error || j.error || t("common.error") };
          }
        } catch (e) {
          item.status = "error";
          item.result = { error: e.message || String(e) };
        }
        window.App.rerender();
      }
    } finally {
      local.uploading = false;
      await fetchCoverage();
      const ok = local.queue.filter((q) => q.status === "done").length;
      const err = local.queue.filter((q) => q.status === "error").length;
      if (ok && !err) showMsg("ok", tf("upload.ok_n", { n: ok }));
      else if (err) showMsg("err", tf("upload.partial", { err, ok }));
      window.App.rerender();
    }
  }

  function bind() {
    const dz = document.getElementById("dropZone");
    const fi = document.getElementById("fileInput");
    const pickBtn = document.getElementById("btnPickFile");
    if (dz && fi) {
      dz.addEventListener("click", (e) => {
        if (e.target.closest("#btnPickFile")) return; // pickBtn handles itself
        fi.click();
      });
      ["dragenter", "dragover"].forEach((ev) =>
        dz.addEventListener(ev, (e) => {
          e.preventDefault(); e.stopPropagation();
          dz.style.background = "color-mix(in oklch, var(--brand) 6%, transparent)";
          dz.style.borderColor = "var(--brand)";
        })
      );
      ["dragleave", "drop"].forEach((ev) =>
        dz.addEventListener(ev, (e) => {
          e.preventDefault(); e.stopPropagation();
          dz.style.background = "";
          dz.style.borderColor = "";
        })
      );
      dz.addEventListener("drop", (e) => {
        const files = e.dataTransfer && e.dataTransfer.files;
        if (files && files.length) addFiles(files);
      });
      fi.addEventListener("change", () => { if (fi.files && fi.files.length) addFiles(fi.files); fi.value = ""; });
      pickBtn?.addEventListener("click", (e) => { e.stopPropagation(); fi.click(); });
    }

    document.getElementById("btnClearQueue")?.addEventListener("click", () => {
      local.queue = []; window.App.rerender();
    });
    document.getElementById("btnReloadCov")?.addEventListener("click", fetchCoverage);
  }

  async function fetchCatalog() {
    try {
      const r = await fetch("api/export-raw.php?action=catalog", { credentials: "same-origin" });
      const j = await r.json();
      local.catalog = j.success ? (j.catalog || []) : [];
    } catch (_) {
      local.catalog = [];
    }
  }

  function bindExport() {
    document.querySelectorAll("[data-pick]").forEach((tr) => tr.addEventListener("click", () => {
      const [platform, fileType] = tr.dataset.pick.split("|");
      const c = (local.catalog || []).find((x) => x.platform === platform && x.file_type === fileType);
      // Mặc định lấy trọn khoảng đang có, người dùng chỉnh lại tuỳ ý.
      local.exportPick = { platform, file_type: fileType, from: (c && c.date_from) || "", to: (c && c.date_to) || "" };
      window.App.rerender();
    }));
    const sync = () => {
      local.exportPick.from = document.getElementById("expFrom")?.value || "";
      local.exportPick.to = document.getElementById("expTo")?.value || "";
      const btn = document.getElementById("expBtn");
      const ready = local.exportPick.platform && local.exportPick.from && local.exportPick.to;
      if (btn) { btn.disabled = !ready; btn.style.opacity = ready ? "" : ".5"; }
    };
    document.getElementById("expFrom")?.addEventListener("change", sync);
    document.getElementById("expTo")?.addEventListener("change", sync);
    document.getElementById("expBtn")?.addEventListener("click", () => {
      const p = local.exportPick;
      if (!p.platform || !p.from || !p.to) return;
      const q = new URLSearchParams({ platform: p.platform, file_type: p.file_type, date_from: p.from, date_to: p.to });
      window.location.href = "api/export-raw.php?" + q.toString();
    });
  }

  function mount() {
    if (local.coverage === null) fetchCoverage();
    if (local.catalog === null) {
      fetchCatalog().then(() => window.App.rerender());
    }
    bind();
    bindExport();
  }

  window.Views.upload = {
    titleKey: "page.upload.title",
    eyebrowKey: "page.upload.eyebrow",
    customToolbar: true,
    render,
    mount,
  };
})();
