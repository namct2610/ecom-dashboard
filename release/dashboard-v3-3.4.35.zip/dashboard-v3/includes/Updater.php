<?php

declare(strict_types=1);

namespace Dashboard;

/**
 * Self-update engine for Dashboard v3.
 *
 * Flow:
 *   1. App uses the production Manifest URL configured in api/update.php.
 *   2. App fetches manifest periodically (cached 6 h in app_settings).
 *   3. If manifest.version > current version → show badge + card in Settings.
 *   4. User clicks "Cập nhật ngay" → applyUpdate() downloads zip, swaps files,
 *      restores preserved paths, writes new version.txt.
 *
 * Manifest format:
 *   {
 *     "version":      "1.1.0",
 *     "download_url": "https://example.com/dashboard-v3-1.1.0.zip",
 *     "changelog":    "- Sửa lỗi X\n- Thêm tính năng Y",
 *     "min_php":      "8.1",
 *     "released_at":  "2024-06-01"
 *   }
 */
class Updater
{
    private string $appRoot;
    private string $versionFile;
    /** @var string[] */
    private array $preservedPaths;

    /**
     * @param string        $appRoot          absolute path of the app (extraction target)
     * @param string|null   $versionFilePath  optional override (default: $appRoot/version.txt).
     *                                        Useful for channel/sub-app updaters (e.g. old/version.txt
     *                                        for the legacy v1 channel) so multiple update channels
     *                                        can coexist.
     * @param string[]|null $preservedPaths   top-level names that won't be overwritten — but only
     *                                        if they already exist in the target. Net-new paths
     *                                        (e.g. /old/ on a fresh install) are still copied.
     *                                        Default: config.php, uploads, .installed, config.local.php.
     */
    public function __construct(string $appRoot, ?string $versionFilePath = null, ?array $preservedPaths = null)
    {
        $this->appRoot     = rtrim($appRoot, '/\\');
        $this->versionFile = $versionFilePath ?? ($this->appRoot . '/version.txt');
        $this->preservedPaths = $preservedPaths ?? ['config.php', 'uploads', '.installed', 'config.local.php'];
    }

    // ── Version ───────────────────────────────────────────────────────────────

    public function getCurrentVersion(): string
    {
        if (!file_exists($this->versionFile)) return '0.0.0';
        return trim((string) file_get_contents($this->versionFile));
    }

    public function hasUpdate(string $latestVersion): bool
    {
        return version_compare($latestVersion, $this->getCurrentVersion(), '>');
    }

    // ── Manifest ──────────────────────────────────────────────────────────────

    /**
     * Fetch and validate the update manifest JSON from the given URL.
     *
     * @return array{version:string,download_url:string,changelog?:string,min_php?:string,released_at?:string}
     * @throws \RuntimeException on network error or invalid manifest
     */
    public function fetchManifest(string $manifestUrl): array
    {
        try {
            return $this->parseManifestResponse($this->httpGet($manifestUrl, 15));
        } catch (\Throwable $primary) {
            // Primary URL (typically GitHub API) failed — could be rate limit
            // (60/hr per IP, shared hosting hits this fast), network error,
            // or an HTML error page. Fall back to the raw CDN URL with a
            // cache-buster so we still get an answer.
            $fallback = $this->fallbackManifestUrl($manifestUrl);
            if ($fallback === null) {
                throw $primary;
            }
            try {
                return $this->parseManifestResponse($this->httpGet($fallback, 15));
            } catch (\Throwable $secondary) {
                throw new \RuntimeException(
                    'Manifest fetch failed. API: ' . $primary->getMessage()
                    . ' | Raw fallback: ' . $secondary->getMessage()
                );
            }
        }
    }

    private function parseManifestResponse(string $response): array
    {
        $data = json_decode($response, true);

        if (!is_array($data)) {
            $preview = substr(trim($response), 0, 120);
            throw new \RuntimeException('Manifest không phải JSON hợp lệ. Nhận được: ' . $preview);
        }

        // GitHub API contents endpoint returns base64-encoded content.
        if (isset($data['content']) && ($data['encoding'] ?? '') === 'base64') {
            $decoded = base64_decode(preg_replace('/\s+/', '', (string) $data['content']));
            $inner   = $decoded !== false ? json_decode($decoded, true) : null;
            if (!is_array($inner)) {
                throw new \RuntimeException('GitHub API trả về content base64 không hợp lệ.');
            }
            $data = $inner;
        }

        // Detect GitHub API error envelopes — they have "message" but no
        // "version", so the legacy "thiếu version" error obscured the real
        // cause (typically rate limit).
        if (empty($data['version']) || empty($data['download_url'])) {
            if (!empty($data['message'])) {
                throw new \RuntimeException('GitHub API: ' . $data['message']);
            }
            throw new \RuntimeException('Manifest thiếu trường "version" hoặc "download_url".');
        }

        return $data;
    }

    /**
     * Build the raw.githubusercontent.com fallback for a GitHub API URL.
     * Returns null when the input URL doesn't follow the API contents
     * pattern (so callers can re-throw the original error).
     */
    private function fallbackManifestUrl(string $apiUrl): ?string
    {
        // api.github.com/repos/<owner>/<repo>/contents/<path>?ref=<branch>
        if (!preg_match(
            '#^https?://api\.github\.com/repos/([^/]+)/([^/]+)/contents/([^?]+)\?ref=([^&]+)#',
            $apiUrl,
            $m
        )) {
            return null;
        }
        return sprintf(
            'https://raw.githubusercontent.com/%s/%s/%s/%s?_=%d',
            $m[1], $m[2], $m[4], $m[3], time()
        );
    }

    // ── Apply update ──────────────────────────────────────────────────────────

    /**
     * Download zip from $downloadUrl, extract it, and replace app files.
     * Preserved paths (never overwritten): config.php, uploads/, .installed
     *
     * @throws \RuntimeException on any failure — caller should log and bubble up.
     */
    public function applyUpdate(string $downloadUrl, string $version): void
    {
        if (!class_exists(\ZipArchive::class)) {
            throw new \RuntimeException('PHP extension "zip" chưa được cài. Cần bật extension=zip.');
        }

        $tmpBase = $this->writableTemp();
        $tmpZip  = $tmpBase . '/dashboard_upd_' . time() . '.zip';
        $tmpDir  = $tmpBase . '/dashboard_upd_' . time() . '_x';

        try {
            // 1. Download
            $this->downloadFile($downloadUrl, $tmpZip);

            // 2. Verify zip opens
            $zip = new \ZipArchive();
            if ($zip->open($tmpZip) !== true) {
                throw new \RuntimeException('File ZIP tải về bị lỗi hoặc không đọc được.');
            }
            $zip->extractTo($tmpDir);
            $zip->close();

            // 3. Find content root (zip may wrap files in one top-level folder)
            $srcRoot = $this->findContentRoot($tmpDir);

            // 4. Back up config.php (safety net — also in preserved list)
            $configSrc = $this->appRoot . '/config.php';
            $configBak = $this->appRoot . '/config.php.update_bak';
            if (file_exists($configSrc)) {
                copy($configSrc, $configBak);
            }

            // 5. Copy new files, skipping preserved paths at root level
            $this->copyRecursive($srcRoot, $this->appRoot, $this->preservedPaths());

            // 6. Restore config.php unconditionally (in case zip contained one)
            if (file_exists($configBak)) {
                copy($configBak, $configSrc);
                @unlink($configBak);
            }

            // 7. Stamp new version (ensure parent dir exists for channel updaters)
            $verDir = dirname($this->versionFile);
            if (!is_dir($verDir)) {
                @mkdir($verDir, 0755, true);
            }
            file_put_contents($this->versionFile, $version . "\n");

        } finally {
            if (file_exists($tmpZip)) @unlink($tmpZip);
            if (is_dir($tmpDir))     $this->removeDir($tmpDir);
        }
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    /** Paths at app root preserved during an update (see __construct). */
    private function preservedPaths(): array
    {
        return $this->preservedPaths;
    }

    /**
     * Recursively copy $src into $dest.
     * $skipNames: basenames to preserve — only skipped if a file/dir with the
     * same name already exists in $dest. This way a fresh install (e.g. one
     * that lays down /old/ for the first time via the main bundle) still gets
     * the directory, while subsequent updates leave it alone.
     */
    private function copyRecursive(string $src, string $dest, array $skipNames): void
    {
        $items = array_diff((array) scandir($src), ['.', '..']);
        foreach ($items as $item) {
            $srcPath  = $src  . '/' . $item;
            $destPath = $dest . '/' . $item;

            if (in_array($item, $skipNames, true) && file_exists($destPath)) {
                continue;
            }

            if (is_dir($srcPath)) {
                if (!is_dir($destPath)) mkdir($destPath, 0755, true);
                $this->copyRecursive($srcPath, $destPath, []);
            } else {
                copy($srcPath, $destPath);
            }
        }
    }

    /**
     * If extracted dir has exactly one sub-directory (common zip layout),
     * return that sub-directory as the real content root.
     */
    private function findContentRoot(string $extractedDir): string
    {
        $items = array_values(array_diff((array) scandir($extractedDir), ['.', '..']));
        if (count($items) === 1 && is_dir($extractedDir . '/' . $items[0])) {
            return $extractedDir . '/' . $items[0];
        }
        return $extractedDir;
    }

    /** Best writable temp dir on shared hosting. */
    private function writableTemp(): string
    {
        $sysTmp = sys_get_temp_dir();
        if (is_writable($sysTmp)) return $sysTmp;

        $uploadsDir = $this->appRoot . '/uploads';
        if (is_writable($uploadsDir)) return $uploadsDir;

        throw new \RuntimeException('Không có thư mục tạm có quyền ghi. Kiểm tra quyền uploads/ hoặc sys_get_temp_dir().');
    }

    /** Stream-download a URL to a local file path. */
    private function downloadFile(string $url, string $dest): void
    {
        $fp = @fopen($dest, 'wb');
        if (!$fp) {
            throw new \RuntimeException("Không thể tạo file tạm: $dest");
        }

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_FILE           => $fp,
            CURLOPT_TIMEOUT        => 120,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => 'DashboardV3-Updater/1.0',
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 3,
        ]);
        $ok       = curl_exec($ch);
        $errno    = curl_errno($ch);
        $error    = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);

        if (!$ok || $errno) {
            @unlink($dest);
            throw new \RuntimeException("Tải file thất bại ($errno): $error");
        }
        if ($httpCode !== 200) {
            @unlink($dest);
            throw new \RuntimeException("HTTP $httpCode khi tải bản cập nhật.");
        }
    }

    /** Fetch a URL and return response body as string. */
    private function httpGet(string $url, int $timeout = 15): string
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => 'DashboardV3-Updater/1.0',
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 3,
            CURLOPT_HTTPHEADER     => [
                'Accept: application/vnd.github+json, application/json',
                'Cache-Control: no-cache',
                'Pragma: no-cache',
            ],
        ]);
        $response = curl_exec($ch);
        $errno    = curl_errno($ch);
        $error    = curl_error($ch);
        curl_close($ch);

        if ($errno) {
            throw new \RuntimeException("Không thể tải manifest: $error");
        }

        return (string) $response;
    }

    private function removeDir(string $dir): void
    {
        if (!is_dir($dir)) return;
        foreach (array_diff((array) scandir($dir), ['.', '..']) as $item) {
            $path = $dir . '/' . $item;
            is_dir($path) ? $this->removeDir($path) : @unlink($path);
        }
        @rmdir($dir);
    }
}
