<?php

declare(strict_types=1);

require dirname(__DIR__) . '/includes/bootstrap.php';

require_auth();
require_method('GET');

// Customer page does a lot of aggregation across the orders table. Give it
// more headroom than PHP's default 30s so a temp-table build or large
// GROUP BY doesn't tank the response on slow shared hosting.
@set_time_limit(120);
@ini_set('memory_limit', '256M');

try {
    $pdo = db($config);

    if (($_GET['action'] ?? '') === 'detail') {
        json_response(build_customer_detail($pdo));
    }

    json_response(build_customers_overview($pdo));
} catch (\Throwable $e) {
    json_exception($e, 'Không thể tải dữ liệu khách hàng.');
}

/**
 * Lookback window for "potential buyers": 12 months ending at the
 * current period's start. Bounded so the orders scan uses the
 * order_created_at index instead of a full table scan.
 */
function potential_lookback_bounds(): array
{
    $range = request_date_range();
    $periodStart = $range ? $range[0] : date('Y-m-01');
    $start = (new DateTimeImmutable($periodStart))->modify('-12 months')->format('Y-m-d');
    return [':since' => $start . ' 00:00:00', ':until' => $periodStart . ' 00:00:00'];
}

/**
 * Cùng một kho được các sàn ghi bằng nhiều tên: "Kho Gò Vấp" và
 * "NPP Gò Vấp (Dũng Tiến)" là một nơi — phần trong ngoặc chỉ là tên thật của
 * NPP. Chuẩn hoá về lõi tên để gộp chung một dòng.
 */
function warehouse_group_key(string $name): string
{
    $core = warehouse_core_name($name);
    if ($core === '') {
        return mb_strtolower(trim($name));
    }

    // Bỏ dấu tiếng Việt cho riêng key, để một kho bị xuất ra cả "Gò Vấp" lẫn
    // "Go Vap" vẫn gộp chung. Nhãn hiển thị vẫn giữ nguyên dấu.
    $folded = $core;
    if (class_exists('\Normalizer')) {
        $decomposed = \Normalizer::normalize($core, \Normalizer::FORM_D);
        if (is_string($decomposed)) {
            $folded = preg_replace('/\p{Mn}+/u', '', $decomposed) ?? $core;
        }
    }
    $folded = str_replace(['đ', 'Đ'], 'd', $folded);

    return mb_strtolower(trim($folded));
}

/** Nhãn hiển thị: bỏ phần trong ngoặc, giữ nguyên tiền tố "Kho"/"NPP". */
function warehouse_display_name(string $name): string
{
    $clean = preg_replace('/\s*\([^)]*\)/u', '', trim($name)) ?? $name;
    $clean = preg_replace('/\s+/u', ' ', $clean) ?? $clean;
    $clean = trim($clean, " \t\n\r-–—,");

    return $clean !== '' ? $clean : trim($name);
}

/** Tên lõi: bỏ phần trong ngoặc và tiền tố loại kho ("Kho", "NPP", ...). */
function warehouse_core_name(string $name): string
{
    $core = warehouse_display_name($name);
    $core = preg_replace('/^(kho|npp|nha\s*phan\s*phoi|nhà\s*phân\s*phối)\s+/iu', '', $core) ?? $core;

    return trim($core);
}

function build_customers_overview(PDO $pdo): array
{
    $params = [];
    $where  = sql_filters($params);
    $where .= " AND normalized_status IN ('completed','delivered')";
    build_customer_snapshot_tables($pdo, $where, $params);

    $summary = $pdo->query("
        SELECT
            COUNT(*) AS total_orders,
            COALESCE(AVG(order_revenue), 0) AS avg_order_value,
            COUNT(DISTINCT NULLIF(buyer_username, '')) AS unique_buyers
        FROM tmp_customer_orders
    ")->fetch() ?: [];

    $buyerStmt = $pdo->query("
        SELECT buyer_username,
               COALESCE(NULLIF(MAX(buyer_name), ''), buyer_username) AS buyer_name,
               COUNT(*) AS order_count,
               COALESCE(SUM(item_qty), 0) AS item_qty,
               COALESCE(SUM(order_revenue), 0) AS revenue
        FROM tmp_customer_orders
        WHERE buyer_username != ''
        GROUP BY buyer_username
        ORDER BY revenue DESC, order_count DESC, item_qty DESC, buyer_username ASC
        LIMIT 20
    ");
    $buyerStats = array_map(static fn(array $row): array => [
        'buyer_username' => (string) $row['buyer_username'],
        'buyer_name'     => (string) $row['buyer_name'],
        'order_count'    => (int) $row['order_count'],
        'item_qty'       => (int) $row['item_qty'],
        'revenue'        => (float) $row['revenue'],
    ], $buyerStmt->fetchAll());

    $totalOrders = (int) ($summary['total_orders'] ?? 0);

    $totalWithCity = (int) $pdo->query("
        SELECT COUNT(*)
        FROM tmp_customer_orders
        WHERE shipping_city != '' AND platform != 'lazada'
    ")->fetchColumn();

    $cityStmt = $pdo->query("
        SELECT shipping_city AS city,
               COUNT(*) AS orders,
               COALESCE(SUM(order_revenue), 0) AS revenue
        FROM tmp_customer_orders
        WHERE shipping_city != '' AND platform != 'lazada'
        GROUP BY shipping_city
        ORDER BY orders DESC, revenue DESC
        LIMIT 12
    ");
    $cities = $cityStmt->fetchAll();

    $topCityOrders = array_sum(array_column($cities, 'orders'));
    $othersOrders  = max(0, $totalWithCity - $topCityOrders);

    $cityList = array_map(static fn(array $c): array => [
        'city'       => (string) $c['city'],
        'orders'     => (int) $c['orders'],
        'revenue'    => (float) $c['revenue'],
        'percentage' => $totalWithCity > 0 ? round(((int) $c['orders']) / $totalWithCity * 100, 1) : 0,
    ], $cities);

    // Warehouse distribution. Unlike city, all three platforms carry it, and it
    // is populated only from the newer order exports — orders imported before the
    // warehouse column existed have '' and simply drop out of this breakdown.
    $totalWithWarehouse = (int) $pdo->query("
        SELECT COUNT(*) FROM tmp_customer_orders WHERE warehouse != ''
    ")->fetchColumn();

    // Gộp trước rồi mới cắt top 12, nếu không một biến thể tên của cùng một kho
    // có thể rơi ra ngoài LIMIT và bị mất khi gộp.
    $warehouseStmt = $pdo->query("
        SELECT warehouse,
               COUNT(*) AS orders,
               COALESCE(SUM(order_revenue), 0) AS revenue
        FROM tmp_customer_orders
        WHERE warehouse != ''
        GROUP BY warehouse
        ORDER BY orders DESC, revenue DESC
    ");

    $warehouseGroups = [];
    foreach ($warehouseStmt->fetchAll() as $w) {
        $raw     = trim((string) $w['warehouse']);
        $orders  = (int) $w['orders'];
        $revenue = (float) $w['revenue'];
        $key     = warehouse_group_key($raw);

        if (!isset($warehouseGroups[$key])) {
            $warehouseGroups[$key] = ['warehouse' => '', 'orders' => 0, 'revenue' => 0.0, 'label_orders' => -1];
        }
        // Nhãn hiển thị lấy theo biến thể nhiều đơn nhất (thường là "Kho X").
        if ($orders > $warehouseGroups[$key]['label_orders']) {
            $warehouseGroups[$key]['warehouse']    = warehouse_display_name($raw);
            $warehouseGroups[$key]['label_orders'] = $orders;
        }
        $warehouseGroups[$key]['orders']  += $orders;
        $warehouseGroups[$key]['revenue'] += $revenue;
    }

    $warehouseGroups = array_values($warehouseGroups);
    usort($warehouseGroups, static fn(array $a, array $b): int =>
        [$b['orders'], $b['revenue']] <=> [$a['orders'], $a['revenue']]
    );

    $warehouseList = array_map(static fn(array $w): array => [
        'warehouse'  => (string) $w['warehouse'],
        'orders'     => (int) $w['orders'],
        'revenue'    => (float) $w['revenue'],
        'percentage' => $totalWithWarehouse > 0 ? round(((int) $w['orders']) / $totalWithWarehouse * 100, 1) : 0,
    ], array_slice($warehouseGroups, 0, 12));

    $hcmStmt = $pdo->query("
        SELECT shipping_district AS district,
               COUNT(*) AS orders
        FROM tmp_customer_orders
        WHERE platform != 'lazada'
          AND shipping_district != ''
          AND (shipping_city LIKE '%Hồ Chí Minh%' OR shipping_city LIKE '%HCM%' OR shipping_city = 'TP. Hồ Chí Minh')
        GROUP BY shipping_district
        ORDER BY orders DESC
        LIMIT 20
    ");

    $hanoiStmt = $pdo->query("
        SELECT shipping_district AS district,
               COUNT(*) AS orders
        FROM tmp_customer_orders
        WHERE platform != 'lazada'
          AND shipping_district != ''
          AND (shipping_city LIKE '%Hà Nội%' OR shipping_city = 'Hà Nội')
        GROUP BY shipping_district
        ORDER BY orders DESC
        LIMIT 20
    ");

    $payStmt = $pdo->query("
        SELECT payment_method, COUNT(*) AS cnt
        FROM tmp_customer_orders
        WHERE payment_method != ''
        GROUP BY payment_method
        ORDER BY cnt DESC
        LIMIT 8
    ");

    $segStmt = $pdo->query("
        SELECT
            SUM(CASE WHEN cnt = 1 THEN 1 ELSE 0 END) AS new_buyers,
            SUM(CASE WHEN cnt >= 2 THEN 1 ELSE 0 END) AS returning_buyers
        FROM (
            SELECT buyer_username, COUNT(*) AS cnt
            FROM tmp_customer_orders
            WHERE buyer_username != ''
            GROUP BY buyer_username
        ) t
    ");
    $seg = $segStmt->fetch() ?: [];

    $pot = ['potential_buyers' => 0];
    if ($totalOrders > 0) {
        $potParams = potential_lookback_bounds();
        $potStmt = $pdo->prepare("
            SELECT COUNT(DISTINCT o.buyer_username) AS potential_buyers
            FROM orders o
            WHERE o.normalized_status IN ('completed','delivered')
              AND o.buyer_username IS NOT NULL AND o.buyer_username != ''
              AND o.order_created_at >= :since
              AND o.order_created_at < :until
              AND NOT EXISTS (
                  SELECT 1
                  FROM tmp_customer_orders co
                  WHERE co.buyer_username = o.buyer_username
              )
        ");
        $potStmt->execute($potParams);
        $pot = $potStmt->fetch() ?: $pot;
    }

    $totalVisits = 0;
    $convRate    = 0;
    try {
        $trafficParams = [];
        $trafficWhere  = sql_filters_traffic($trafficParams);
        $visitStmt = $pdo->prepare("
            SELECT COALESCE(SUM(visits), 0) AS total_visits
            FROM traffic_daily {$trafficWhere}
        ");
        $visitStmt->execute($trafficParams);
        $visitsRow   = $visitStmt->fetch() ?: [];
        $totalVisits = (int) ($visitsRow['total_visits'] ?? 0);
        $convRate    = $totalVisits > 0 ? round($totalOrders / $totalVisits * 100, 2) : 0;
    } catch (\Throwable $ignored) {
        // traffic_daily unavailable — conv_rate defaults to 0, not a fatal error
    }

    return [
        'success'           => true,
        'lazada_excluded'   => true,
        'summary'           => [
            'total_orders'    => $totalOrders,
            'avg_order_value' => round((float) ($summary['avg_order_value'] ?? 0), 0),
            'unique_buyers'   => (int) ($summary['unique_buyers'] ?? 0),
            'total_visits'    => $totalVisits,
            'conv_rate'       => $convRate,
        ],
        'customer_segments' => [
            'new_buyers'       => (int) ($seg['new_buyers'] ?? 0),
            'returning_buyers' => (int) ($seg['returning_buyers'] ?? 0),
            'potential_buyers' => (int) ($pot['potential_buyers'] ?? 0),
        ],
        'buyer_stats'       => $buyerStats,
        'city_distribution'   => $cityList,
        'city_total'          => $totalWithCity,
        'warehouse_distribution' => $warehouseList,
        'warehouse_total'        => $totalWithWarehouse,
        'city_others_orders'  => $othersOrders,
        'city_others_pct'     => $totalWithCity > 0 ? round($othersOrders / $totalWithCity * 100, 1) : 0,
        'hcm_districts'     => $hcmStmt->fetchAll(),
        'hanoi_districts'   => $hanoiStmt->fetchAll(),
        'payment_methods'   => $payStmt->fetchAll(),
    ];
}

/**
 * Collation of orders.buyer_username, as a COLLATE clause (or '' if unknown).
 *
 * The temp table below is compared against orders.buyer_username. Without an
 * explicit collation MySQL gives the temp table the server default, which is
 * utf8mb4_0900_ai_ci on 8.0+ — while an orders table restored from an older
 * dump is utf8mb4_general_ci. That mix raises errno 1267 on the comparison.
 * Pinning the temp table to whatever orders actually uses keeps both cases working.
 */
function orders_buyer_collate_clause(PDO $pdo): string
{
    $collation = $pdo->query("
        SELECT collation_name FROM information_schema.columns
        WHERE table_schema = DATABASE() AND table_name = 'orders' AND column_name = 'buyer_username'
    ")->fetchColumn();

    // Interpolated, so accept only a plain utf8mb4 collation identifier.
    if (!is_string($collation) || !preg_match('/^utf8mb4_[a-z0-9_]+$/', $collation)) {
        return '';
    }
    return " COLLATE={$collation}";
}

function build_customer_snapshot_tables(PDO $pdo, string $where, array $params): void
{
    $collate = orders_buyer_collate_clause($pdo);

    $pdo->exec("DROP TEMPORARY TABLE IF EXISTS tmp_customer_orders");
    $pdo->exec("
        CREATE TEMPORARY TABLE tmp_customer_orders (
            platform VARCHAR(20) NOT NULL,
            order_id VARCHAR(100) NOT NULL,
            buyer_username VARCHAR(255) NOT NULL DEFAULT '',
            buyer_name VARCHAR(255) NOT NULL DEFAULT '',
            order_created_at DATETIME NOT NULL,
            item_qty INT NOT NULL DEFAULT 0,
            order_revenue DECIMAL(15,2) NOT NULL DEFAULT 0,
            shipping_address VARCHAR(500) NOT NULL DEFAULT '',
            shipping_district VARCHAR(100) NOT NULL DEFAULT '',
            shipping_city VARCHAR(100) NOT NULL DEFAULT '',
            warehouse VARCHAR(255) NOT NULL DEFAULT '',
            payment_method VARCHAR(100) NOT NULL DEFAULT '',
            PRIMARY KEY (platform, order_id),
            INDEX idx_tmp_customer_buyer (buyer_username(100)),
            INDEX idx_tmp_customer_city (shipping_city(50), shipping_district(50))
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4{$collate}
    ");

    $tmpOrdersStmt = $pdo->prepare("
        INSERT INTO tmp_customer_orders (
            platform, order_id, buyer_username, buyer_name, order_created_at,
            item_qty, order_revenue, shipping_address, shipping_district,
            shipping_city, warehouse, payment_method
        )
        SELECT platform,
               order_id,
               COALESCE(NULLIF(MAX(buyer_username), ''), '') AS buyer_username,
               COALESCE(NULLIF(MAX(buyer_name), ''), MAX(buyer_username), '') AS buyer_name,
               MIN(order_created_at) AS order_created_at,
               COALESCE(SUM(quantity), 0) AS item_qty,
               -- Doanh thu mỗi đơn = tổng tiền hàng các dòng, cùng cơ sở với
               -- KPI Doanh thu ở dashboard (xem api/v2-data.php). Không dùng
               -- cột order_total nữa, để hai trang không ra hai con số khác nhau.
               COALESCE(SUM(subtotal_after_discount), 0) AS order_revenue,
               COALESCE(MAX(shipping_address), '') AS shipping_address,
               COALESCE(MAX(shipping_district), '') AS shipping_district,
               COALESCE(MAX(shipping_city), '') AS shipping_city,
               COALESCE(MAX(warehouse), '') AS warehouse,
               COALESCE(MAX(payment_method), '') AS payment_method
        FROM orders {$where}
        GROUP BY platform, order_id
    ");
    $tmpOrdersStmt->execute($params);
}

function build_customer_detail(PDO $pdo): array
{
    $buyerUsername = trim((string) ($_GET['buyer_username'] ?? ''));
    if ($buyerUsername === '') {
        json_error('Thiếu buyer_username.', 422);
    }

    $params = [];
    $where  = sql_filters($params);
    $where .= " AND normalized_status IN ('completed','delivered')";

    $filteredWhere = $where . " AND buyer_username = :buyer_username";
    $filteredStmt = $pdo->prepare("
        SELECT COUNT(*) AS order_count,
               COALESCE(SUM(item_qty), 0) AS item_qty,
               COALESCE(SUM(order_revenue), 0) AS revenue
        FROM (
            SELECT platform,
                   order_id,
                   COALESCE(SUM(quantity), 0) AS item_qty,
                   COALESCE(SUM(subtotal_after_discount), 0) AS order_revenue
            FROM orders {$filteredWhere}
            GROUP BY platform, order_id
        ) filtered_orders
    ");
    $filteredStmt->execute($params + [':buyer_username' => $buyerUsername]);
    $filtered = $filteredStmt->fetch() ?: [];

    $lifetimeStmt = $pdo->prepare("
        SELECT COUNT(*) AS order_count,
               COALESCE(SUM(item_qty), 0) AS item_qty,
               COALESCE(SUM(order_revenue), 0) AS revenue,
               MIN(order_created_at) AS first_purchase_at,
               MAX(order_created_at) AS last_purchase_at
        FROM (
            SELECT platform,
                   order_id,
                   MIN(order_created_at) AS order_created_at,
                   COALESCE(SUM(quantity), 0) AS item_qty,
                   COALESCE(SUM(subtotal_after_discount), 0) AS order_revenue
            FROM orders
            WHERE buyer_username = ?
              AND normalized_status IN ('completed','delivered')
            GROUP BY platform, order_id
        ) lifetime_orders
    ");
    $lifetimeStmt->execute([$buyerUsername]);
    $lifetime = $lifetimeStmt->fetch() ?: [];

    if ((int) ($lifetime['order_count'] ?? 0) === 0 && (int) ($filtered['order_count'] ?? 0) === 0) {
        json_error('Không tìm thấy khách hàng.', 404);
    }

    $profileStmt = $pdo->prepare("
        SELECT COALESCE(NULLIF(buyer_name, ''), buyer_username) AS buyer_name,
               buyer_username,
               shipping_address,
               shipping_district,
               shipping_city,
               order_created_at
        FROM orders
        WHERE buyer_username = ?
        ORDER BY
            (shipping_address IS NULL OR shipping_address = '') ASC,
            order_created_at DESC,
            id DESC
        LIMIT 1
    ");
    $profileStmt->execute([$buyerUsername]);
    $profile = $profileStmt->fetch() ?: [
        'buyer_name'        => $buyerUsername,
        'buyer_username'    => $buyerUsername,
        'shipping_address'  => null,
        'shipping_district' => null,
        'shipping_city'     => null,
    ];

    $historyStmt = $pdo->prepare("
        SELECT platform,
               order_id,
               MIN(order_created_at) AS order_created_at,
               COALESCE(SUM(subtotal_after_discount), 0) AS order_total,
               MAX(normalized_status) AS normalized_status,
               COALESCE(SUM(quantity), 0) AS item_qty,
               MAX(payment_method) AS payment_method,
               MAX(shipping_address) AS shipping_address,
               MAX(shipping_district) AS shipping_district,
               MAX(shipping_city) AS shipping_city,
               SUBSTRING(GROUP_CONCAT(DISTINCT TRIM(product_name) ORDER BY product_name SEPARATOR ' • '), 1, 500) AS products
        FROM orders
        WHERE buyer_username = ?
        GROUP BY platform, order_id
        ORDER BY order_created_at DESC
        LIMIT 30
    ");
    $historyStmt->execute([$buyerUsername]);
    $orders = array_map(static fn(array $row): array => [
        'platform'          => (string) $row['platform'],
        'order_id'          => (string) $row['order_id'],
        'order_created_at'  => $row['order_created_at'],
        'order_total'       => (float) ($row['order_total'] ?? 0),
        'normalized_status' => (string) ($row['normalized_status'] ?? 'pending'),
        'item_qty'          => (int) ($row['item_qty'] ?? 0),
        'payment_method'    => (string) ($row['payment_method'] ?? ''),
        'shipping_address'  => (string) ($row['shipping_address'] ?? ''),
        'shipping_district' => (string) ($row['shipping_district'] ?? ''),
        'shipping_city'     => (string) ($row['shipping_city'] ?? ''),
        'products'          => (string) ($row['products'] ?? ''),
    ], $historyStmt->fetchAll());

    return [
        'success' => true,
        'profile' => [
            'buyer_username'    => (string) ($profile['buyer_username'] ?? $buyerUsername),
            'buyer_name'        => (string) ($profile['buyer_name'] ?? $buyerUsername),
            'shipping_address'  => (string) ($profile['shipping_address'] ?? ''),
            'shipping_district' => (string) ($profile['shipping_district'] ?? ''),
            'shipping_city'     => (string) ($profile['shipping_city'] ?? ''),
            'first_purchase_at' => $lifetime['first_purchase_at'] ?? null,
            'last_purchase_at'  => $lifetime['last_purchase_at'] ?? null,
        ],
        'summary' => [
            'filtered_order_count' => (int) ($filtered['order_count'] ?? 0),
            'filtered_item_qty'    => (int) ($filtered['item_qty'] ?? 0),
            'filtered_revenue'     => (float) ($filtered['revenue'] ?? 0),
            'lifetime_order_count' => (int) ($lifetime['order_count'] ?? 0),
            'lifetime_item_qty'    => (int) ($lifetime['item_qty'] ?? 0),
            'lifetime_revenue'     => (float) ($lifetime['revenue'] ?? 0),
        ],
        'orders' => $orders,
    ];
}
